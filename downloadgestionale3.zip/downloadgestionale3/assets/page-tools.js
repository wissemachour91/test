(()=>{if(!document.body.classList.contains('app-page'))return;
const current=(location.pathname.split('/').pop()||'').toLowerCase();
if(current!=='dashboard.php'){
 const header=document.querySelector('.module-header');
 if(header&&!header.querySelector('.smart-back-button,.back-link')){
  const back=document.createElement('button');back.type='button';back.className='smart-back-button no-print';back.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/><path d="M9 12h11"/></svg><span>Torna indietro</span>';
  back.addEventListener('click',()=>{const ref=document.referrer;try{if(ref&&new URL(ref).origin===location.origin){history.back();return}}catch(e){}location.href='dashboard.php'});
  header.appendChild(back);
 }
}
if(document.querySelector('.page-direct-link'))return;const g=window.MQH_GLOBAL_APPEARANCE||{};if(g.qrEnabled===false)return;const url=location.href.split('#')[0],size=Math.max(48,Math.min(140,Number(g.qrSize)||76)),position=['left','center','right'].includes(g.qrPosition)?g.qrPosition:'right',footer=document.createElement('footer');footer.className='page-direct-link qr-position-'+position;const label=(g.qrLabel||'Accesso diretto'),caption=(g.qrCaption||'Scansiona'),title=document.title||'Pagina',showTitle=g.qrShowPageTitle!==false;footer.style.setProperty('--qr-size',size+'px');footer.innerHTML=`${showTitle?`<div><small>${label}</small><b>${title}</b></div>`:''}<a href="${url}" title="Apri questa pagina"><img alt="QR code link diretto" width="${size}" height="${size}"><span>${caption}</span></a>`;const img=footer.querySelector('img');img.src='https://api.qrserver.com/v1/create-qr-code/?size='+(size*2)+'x'+(size*2)+'&margin=4&data='+encodeURIComponent(url);img.addEventListener('error',()=>footer.classList.add('qr-unavailable'));document.body.appendChild(footer)})();
