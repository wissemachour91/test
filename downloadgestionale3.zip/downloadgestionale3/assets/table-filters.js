(()=>{
 const clean=v=>(v||'').replace(/\s+/g,' ').trim();
 const tables=[...document.querySelectorAll('table')].filter(t=>t.querySelector('thead th')&&t.querySelector('tbody tr'));
 tables.forEach((table,tableIndex)=>{
  if(table.dataset.filtersReady==='1'||table.dataset.noFilters==='1')return;
  const headers=[...table.querySelectorAll('thead th')];
  const rows=[...table.querySelectorAll('tbody tr')].filter(r=>r.children.length>1&&!r.querySelector('td[colspan]'));
  if(!rows.length)return;
  const filterable=[];
  headers.forEach((th,index)=>{
   const label=clean(th.textContent);
   if(!label||/^(azioni|comandi|decisione|approva|allegato|rif\.?|scadenza|descrizione)$/i.test(label))return;
   const values=[...new Set(rows.map(r=>clean(r.children[index]?.textContent)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'it',{numeric:true}));
   const alwaysVisible=/^(origine|categoria)$/i.test(label);
   if(values.length>=1&&values.length<=60&&(alwaysVisible||values.length>1))filterable.push({index,label,values});
  });
  if(!filterable.length)return;
  const bar=document.createElement('div');bar.className='registry-filters';bar.setAttribute('aria-label','Filtri registro');
  const title=document.createElement('div');title.className='registry-filters-title';title.innerHTML='<b>Filtra registro</b><small>Aggiornamento automatico</small>';bar.appendChild(title);
  const controls=document.createElement('div');controls.className='registry-filter-controls';bar.appendChild(controls);
  const selects=[];
  const apply=()=>{
   let shown=0;
   rows.forEach(row=>{const visible=selects.every(({select,index})=>!select.value||clean(row.children[index]?.textContent)===select.value);row.hidden=!visible;if(visible)shown++;});
   count.textContent=shown+' di '+rows.length+' record';
   reset.hidden=!selects.some(x=>x.select.value);
  };
  filterable.forEach(({index,label,values})=>{
   const wrap=document.createElement('label');wrap.className='registry-filter';
   const cap=document.createElement('span');cap.textContent=label;wrap.appendChild(cap);
   const select=document.createElement('select');select.setAttribute('aria-label','Filtra per '+label);
   select.innerHTML='<option value="">Tutti</option>'+values.map(v=>'<option></option>').join('');
   [...select.options].slice(1).forEach((o,i)=>{o.value=values[i];o.textContent=values[i]});
   select.addEventListener('change',apply);wrap.appendChild(select);controls.appendChild(wrap);selects.push({select,index});
  });
  const actions=document.createElement('div');actions.className='registry-filter-actions';
  const count=document.createElement('span');count.className='registry-filter-count';count.textContent=rows.length+' di '+rows.length+' record';
  const reset=document.createElement('button');reset.type='button';reset.className='registry-filter-reset';reset.textContent='Azzera filtri';reset.hidden=true;reset.addEventListener('click',()=>{selects.forEach(x=>x.select.value='');apply()});
  actions.append(count,reset);bar.appendChild(actions);
  const host=table.closest('.register-table-wrap,.table-wrap,.panel')||table.parentElement;host.parentNode.insertBefore(bar,host);
  table.dataset.filtersReady='1';
 });
})();
