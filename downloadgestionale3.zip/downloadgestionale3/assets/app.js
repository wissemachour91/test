const $=(s,p=document)=>p.querySelector(s), $$=(s,p=document)=>[...p.querySelectorAll(s)];
const root=document.documentElement, profileButton=$('#profileButton'), profileMenu=$('#profileMenu'), sidebar=$('#sidebar'), overlay=$('#overlay'), drawer=$('#appearanceDrawer'), toast=$('#toast');
const globalAppearance=window.MQH_GLOBAL_APPEARANCE||{};const defaults={layout:globalAppearance.layout||'classic',theme:globalAppearance.theme||'indigo',dark:!!globalAppearance.dark,motion:true,dense:false,collapsed:false};
let storedPrefs={};
try{storedPrefs=JSON.parse(localStorage.getItem('mqh-prefs')||'{}')||{}}catch(error){localStorage.removeItem('mqh-prefs')}
let prefs={...defaults,...storedPrefs};
if(!['classic','compact','topnav','floating','focus','executive'].includes(prefs.layout)) prefs.layout=defaults.layout;
if(!['indigo','ocean','emerald','sunset','graphite'].includes(prefs.theme)) prefs.theme=defaults.theme;
function applyPrefs(showToast=false){root.dataset.layout=prefs.layout;root.dataset.theme=prefs.theme;root.classList.toggle('dark',prefs.dark);root.classList.toggle('no-motion',!prefs.motion);root.classList.toggle('dense',prefs.dense);root.classList.toggle('nav-collapsed',prefs.collapsed);$('#darkMode').checked=prefs.dark;$('#motionToggle').checked=prefs.motion;$('#densityToggle').checked=prefs.dense;$$('[data-layout-choice]').forEach(b=>b.classList.toggle('selected',b.dataset.layoutChoice===prefs.layout));$$('[data-theme-choice]').forEach(b=>b.classList.toggle('selected',b.dataset.themeChoice===prefs.theme));localStorage.setItem('mqh-prefs',JSON.stringify(prefs));if(showToast){toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1400)}}
function closeMenus(){profileMenu?.classList.remove('show');profileButton?.setAttribute('aria-expanded','false')}
profileButton?.addEventListener('click',e=>{e.stopPropagation();profileMenu.classList.toggle('show');profileButton.setAttribute('aria-expanded',profileMenu.classList.contains('show'))});
document.addEventListener('click',closeMenus);profileMenu?.addEventListener('click',e=>e.stopPropagation());
function openDrawer(){drawer.classList.add('show');drawer.setAttribute('aria-hidden','false');overlay.classList.add('show');closeMenus()}
function closeDrawer(){drawer.classList.remove('show');drawer.setAttribute('aria-hidden','true');overlay.classList.remove('show');sidebar.classList.remove('open')}
$('#appearanceButton')?.addEventListener('click',openDrawer);$('#quickAppearance')?.addEventListener('click',openDrawer);$('#closeAppearance')?.addEventListener('click',closeDrawer);overlay?.addEventListener('click',closeDrawer);
$('#menuButton')?.addEventListener('click',()=>{sidebar.classList.add('open');overlay.classList.add('show')});
$('#collapseButton')?.addEventListener('click',()=>{
  prefs.collapsed=!prefs.collapsed;
  // Quando si compatta, chiude correttamente tutti i sottomenu e pulisce gli stati visivi.
  root.classList.remove('submenu-open');
  $$('.nav-group.has-children').forEach(group=>group.classList.remove('expanded'));
  $$('.nav-link,.subnav-link').forEach(item=>item.classList.remove('active','parent-active'));
  // Mantiene Dashboard come voce attiva se non è selezionata una pagina specifica.
  if(prefs.collapsed) $('.nav-link[data-section="Dashboard"]')?.classList.add('active');
  applyPrefs(true);
  const button=$('#collapseButton');
  if(button){
    button.textContent=prefs.collapsed?'›':'‹';
    button.setAttribute('aria-label',prefs.collapsed?'Espandi menu':'Compatta menu');
    button.title=prefs.collapsed?'Espandi menu':'Compatta menu';
  }
});
$$('.nav-link:not(.nav-group.has-children > .nav-link)').forEach(link=>link.addEventListener('click',e=>{
  if(link.dataset.direct==='1')return;
  e.preventDefault();
  $$('.nav-link,.subnav-link').forEach(x=>x.classList.remove('active','parent-active'));
  $$('.nav-group.has-children').forEach(group=>group.classList.remove('expanded'));
  root.classList.remove('submenu-open');link.classList.add('active');
  const label=link.dataset.section;if($('#sectionTitle'))$('#sectionTitle').textContent=label;
  sidebar.classList.remove('open');overlay.classList.remove('show');
}));
$$('[data-layout-choice]').forEach(b=>b.addEventListener('click',()=>{prefs.layout=b.dataset.layoutChoice;localStorage.setItem('mqh-user-customized','1');root.classList.remove('submenu-open');$$('.nav-group').forEach(g=>g.classList.remove('expanded'));applyPrefs(true)}));
$$('[data-theme-choice]').forEach(button=>button.addEventListener('click',()=>{
  const theme=button.dataset.themeChoice;
  if(!['indigo','ocean','emerald','sunset','graphite'].includes(theme)) return;
  prefs.theme=theme;localStorage.setItem('mqh-user-customized','1');
  root.dataset.theme=theme;if(window.MQH_IS_ADMIN)fetch('appearance_api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({theme,csrf:window.MQH_CSRF})}).catch(()=>{});
  applyPrefs(true);
}));
$('#darkMode')?.addEventListener('change',e=>{prefs.dark=e.target.checked;localStorage.setItem('mqh-user-customized','1');applyPrefs(true);if(window.MQH_IS_ADMIN)fetch('appearance_api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dark:prefs.dark,csrf:window.MQH_CSRF})}).catch(()=>{})});$('#motionToggle')?.addEventListener('change',e=>{prefs.motion=e.target.checked;localStorage.setItem('mqh-user-customized','1');applyPrefs(true)});$('#densityToggle')?.addEventListener('change',e=>{prefs.dense=e.target.checked;localStorage.setItem('mqh-user-customized','1');applyPrefs(true)});
$('#resetAppearance')?.addEventListener('click',()=>{prefs={...defaults};applyPrefs(true)});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer();if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('.search-box input')?.focus()}});
const toggle=$('[data-password-toggle]');toggle?.addEventListener('click',e=>{const input=$('#password'),show=input.type==='password';input.type=show?'text':'password';e.currentTarget.textContent=show?'Nascondi':'Mostra'});
applyPrefs();
if($('#collapseButton')){
  $('#collapseButton').textContent=prefs.collapsed?'›':'‹';
  $('#collapseButton').setAttribute('aria-label',prefs.collapsed?'Espandi menu':'Compatta menu');
  $('#collapseButton').title=prefs.collapsed?'Espandi menu':'Compatta menu';
}
// Navigazione macro categorie con pagina a griglia
const macroHub=$('#macroHub'), macroHubTitle=$('#macroHubTitle'), macroHubDescription=$('#macroHubDescription');
const macroDescriptions={
 'Gestione NC':'Scegli lo strumento per registrare, consultare o analizzare le non conformità.',
 'Gestione segnalazioni':'Apri, consulta e monitora le segnalazioni operative.',
 'Gestione attività':'Assegna attività, controlla le scadenze e gestisci il lavoro personale.',
 'Assistenza Tecnica':'Apri e consulta i ticket dedicati al supporto post-vendita.',
 'Aspetti Tecnici':'Gestisci richieste account, problemi tecnici e amministrazione utenti.'
};
function clearNavSelection(){ $$('.nav-link').forEach(x=>x.classList.remove('active','parent-active')); }
function showDashboard(){
 document.body.classList.remove('category-view');document.body.classList.add('dashboard-view');macroHub.hidden=true; $$('[data-dashboard-section]').forEach(x=>x.hidden=false); $$('.macro-card-set').forEach(x=>x.hidden=true);
 clearNavSelection(); $('.nav-link[data-section="Dashboard"]')?.classList.add('active');
 history.replaceState(null,'',location.pathname);
}
function showMacroHub(name){
 document.body.classList.remove('dashboard-view');document.body.classList.add('category-view');const set=$(`[data-macro-cards="${CSS.escape(name)}"]`); if(!set)return;
 $$('[data-dashboard-section]').forEach(x=>x.hidden=true); $$('.macro-card-set').forEach(x=>x.hidden=true); set.hidden=false; macroHub.hidden=false;
 macroHubTitle.textContent=name; macroHubDescription.textContent=macroDescriptions[name]||'Seleziona una funzione per continuare.';
 clearNavSelection(); $(`.nav-link[data-section="${CSS.escape(name)}"]`)?.classList.add('active');
 root.classList.remove('submenu-open'); sidebar.classList.remove('open'); overlay.classList.remove('show'); if(new URLSearchParams(location.search).get('section')!==name)history.pushState({section:name},'',location.pathname+'?section='+encodeURIComponent(name)); window.scrollTo({top:0,behavior:'smooth'});
}
$$('.nav-link').forEach(link=>link.addEventListener('click',e=>{
 const name=link.dataset.section;
 if(link.dataset.direct==='1')return;
 e.preventDefault();e.stopPropagation();
 if(link.dataset.hasHub==='1')showMacroHub(name);else if(name==='Dashboard')showDashboard();
}));
$('#hubBack')?.addEventListener('click',()=>{if(history.length>1)history.back();else showDashboard()});
const initialSection=new URLSearchParams(location.search).get('section');if(initialSection){requestAnimationFrame(()=>showMacroHub(initialSection));}
window.addEventListener('popstate',()=>{const section=new URLSearchParams(location.search).get('section');if(section)showMacroHub(section);else showDashboard();});
$$('.macro-card').forEach(card=>card.addEventListener('click',e=>{
 if(card.getAttribute('href')&&card.getAttribute('href')!=='#')return;
 e.preventDefault(); const name=card.dataset.childSection;
 $$('.macro-card').forEach(x=>x.classList.remove('selected')); card.classList.add('selected');
 toast.textContent=name+' selezionato';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1300);
}));
// Personalizzazione dei due loghi nella barra superiore
const logoDefaults={logo1:globalAppearance.logo1||'assets/logos/logo-primary.svg',logo2:globalAppearance.logo2||'assets/logos/logo-secondary.svg',logoSize:globalAppearance.logoSize||42,logoGap:globalAppearance.logoGap??6,logoLayout:globalAppearance.logoLayout||'vertical',showLogo1:globalAppearance.showLogo1!==false,showLogo2:globalAppearance.showLogo2!==false};
let logoPrefs={...logoDefaults};
if(window.MQH_IS_ADMIN){try{logoPrefs={...logoDefaults,...(JSON.parse(localStorage.getItem('mqh-logo-prefs')||'{}')||{})}}catch(error){localStorage.removeItem('mqh-logo-prefs')}}
function applyLogoPrefs(save=false){
  const box=$('#topbarLogos'); if(!box) return;
  const size=Math.max(24,Math.min(120,Number(logoPrefs.logoSize)||42));
  const gap=Math.max(0,Math.min(24,Number(logoPrefs.logoGap)||6));
  box.style.setProperty('--logo-size',size+'px');box.style.setProperty('--logo-gap',gap+'px');
  box.classList.toggle('horizontal',logoPrefs.logoLayout==='horizontal');
  [['#displayLogo1','#previewLogo1','logo1','showLogo1'],['#displayLogo2','#previewLogo2','logo2','showLogo2']].forEach(([display,preview,key,visible])=>{
    const source=logoPrefs[key]||logoDefaults[key];$(display).src=source;$(preview).src=source;$(display).closest('.topbar-logo').classList.toggle('hidden',!logoPrefs[visible]);
  });
  $('#logoSize').value=size;$('#logoGap').value=gap;$('#logoSizeValue').textContent=size+' px';$('#logoGapValue').textContent=gap+' px';
  $('#showLogo1').checked=!!logoPrefs.showLogo1;$('#showLogo2').checked=!!logoPrefs.showLogo2;
  $$('[data-logo-layout]').forEach(b=>b.classList.toggle('selected',b.dataset.logoLayout===logoPrefs.logoLayout));
  if(save){try{localStorage.setItem('mqh-logo-prefs',JSON.stringify(logoPrefs))}catch(error){toast.textContent='Immagine troppo grande per il browser';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200)}}
}
function loadLogo(input,key){const file=input.files?.[0];if(!file)return;if(!file.type.startsWith('image/'))return;if(file.size>1500000){toast.textContent='Logo troppo grande: massimo 1,5 MB';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200);input.value='';return}const reader=new FileReader();reader.onload=()=>{logoPrefs[key]=reader.result;applyLogoPrefs(true);toast.textContent='Logo aggiornato';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1400)};reader.readAsDataURL(file)}
$('#logoInput1')?.addEventListener('change',e=>loadLogo(e.target,'logo1'));$('#logoInput2')?.addEventListener('change',e=>loadLogo(e.target,'logo2'));
$('#logoSize')?.addEventListener('input',e=>{logoPrefs.logoSize=Number(e.target.value);applyLogoPrefs(true)});$('#logoGap')?.addEventListener('input',e=>{logoPrefs.logoGap=Number(e.target.value);applyLogoPrefs(true)});
$$('[data-logo-layout]').forEach(b=>b.addEventListener('click',()=>{logoPrefs.logoLayout=b.dataset.logoLayout;applyLogoPrefs(true)}));
$('#showLogo1')?.addEventListener('change',e=>{logoPrefs.showLogo1=e.target.checked;applyLogoPrefs(true)});$('#showLogo2')?.addEventListener('change',e=>{logoPrefs.showLogo2=e.target.checked;applyLogoPrefs(true)});
$('#resetLogos')?.addEventListener('click',()=>{logoPrefs={...logoDefaults};localStorage.removeItem('mqh-logo-prefs');applyLogoPrefs(false);$('#logoInput1').value='';$('#logoInput2').value='';toast.textContent='Loghi ripristinati';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1400)});
applyLogoPrefs();
if(window.MQH_IS_ADMIN){try{const local=JSON.parse(localStorage.getItem('mqh-logo-prefs')||'null');if(local&&local.logo1&&local.logo2&&localStorage.getItem('mqh-logo-global-migrated')!=='1'){fetch('appearance_api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...local,theme:prefs.theme,layout:prefs.layout,dark:prefs.dark,csrf:window.MQH_CSRF})}).then(r=>r.json()).then(x=>{if(x.ok)localStorage.setItem('mqh-logo-global-migrated','1')}).catch(()=>{});}}catch(e){}}
