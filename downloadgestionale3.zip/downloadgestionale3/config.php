<?php
declare(strict_types=1);

const APP_NAME = 'Mesar Quality Hub';
const DATA_DIR = __DIR__ . '/data';
const USERS_FILE = DATA_DIR . '/users.json';
const PERMISSIONS_FILE = DATA_DIR . '/permissions.json';
const NC_FILE = DATA_DIR . '/nonconformities.json';
const NC_UPLOAD_DIR = DATA_DIR . '/uploads/nc';
const DB_CONFIG_FILE = DATA_DIR . '/database.php';
const APPEARANCE_FILE = DATA_DIR . '/appearance.json';
const NC_DETAILS_FILE = DATA_DIR . '/nc_details.json';
const NC_ACTIONS_FILE = DATA_DIR . '/nc_actions.json';
const SEG_FILE = DATA_DIR . '/segnalazioni.json';
function appearance_defaults(): array {return ['revision'=>1,'theme'=>'ocean','dark'=>false,'layout'=>'classic','logo1'=>'assets/logos/logo-primary.svg','logo2'=>'assets/logos/logo-secondary.svg','logoSize'=>42,'logoGap'=>6,'logoLayout'=>'vertical','showLogo1'=>true,'showLogo2'=>true,'qrEnabled'=>true,'qrSize'=>76,'qrPosition'=>'right','qrLabel'=>'Accesso diretto','qrCaption'=>'Scansiona','qrShowPageTitle'=>true];}
function load_global_appearance(): array {$d=appearance_defaults();if(file_exists(APPEARANCE_FILE)){$x=json_decode((string)file_get_contents(APPEARANCE_FILE),true);if(is_array($x))$d=array_merge($d,$x);}return $d;}
function save_global_appearance(array $input): bool {$d=load_global_appearance();$d['revision']=((int)($d['revision']??0))+1;$themes=['indigo','ocean','emerald','sunset','graphite'];$layouts=['classic','compact','topnav','floating','focus','executive'];if(isset($input['theme'])&&in_array($input['theme'],$themes,true))$d['theme']=$input['theme'];if(isset($input['layout'])&&in_array($input['layout'],$layouts,true))$d['layout']=$input['layout'];foreach(['dark','showLogo1','showLogo2','qrEnabled','qrShowPageTitle'] as $k)if(array_key_exists($k,$input))$d[$k]=(bool)$input[$k];if(isset($input['logoSize']))$d['logoSize']=max(24,min(72,(int)$input['logoSize']));if(isset($input['logoGap']))$d['logoGap']=max(0,min(24,(int)$input['logoGap']));if(isset($input['qrSize']))$d['qrSize']=max(48,min(140,(int)$input['qrSize']));if(isset($input['qrPosition'])&&in_array($input['qrPosition'],['left','center','right'],true))$d['qrPosition']=$input['qrPosition'];foreach(['qrLabel','qrCaption'] as $k)if(isset($input[$k]))$d[$k]=mb_substr(trim((string)$input[$k]),0,40);if(isset($input['logoLayout'])&&in_array($input['logoLayout'],['vertical','horizontal'],true))$d['logoLayout']=$input['logoLayout'];foreach(['logo1','logo2'] as $k)if(isset($input[$k])&&is_string($input[$k])&&strlen($input[$k])<2200000)$d[$k]=$input[$k];if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0775,true);return file_put_contents(APPEARANCE_FILE,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false;}
function appearance_bootstrap(): string {$g=load_global_appearance();return '<script>window.MQH_GLOBAL_APPEARANCE='.json_encode($g,JSON_UNESCAPED_SLASHES|JSON_HEX_TAG).';(function(){try{const g=window.MQH_GLOBAL_APPEARANCE||{},custom=localStorage.getItem("mqh-user-customized")==="1",u=custom?JSON.parse(localStorage.getItem("mqh-prefs")||"null"):null,p=u||{theme:g.theme||"ocean",layout:g.layout||"classic",dark:!!g.dark,motion:true,dense:false,collapsed:false};document.documentElement.dataset.theme=p.theme||"ocean";document.documentElement.dataset.layout=p.layout||"classic";document.documentElement.classList.toggle("dark",!!p.dark);if(!custom)localStorage.setItem("mqh-prefs",JSON.stringify(p));}catch(e){}})();</script>';}

function db(): ?PDO {
 static $pdo=false; if($pdo instanceof PDO)return $pdo; if($pdo===null)return null;
 if(!file_exists(DB_CONFIG_FILE)){ $pdo=null; return null; }
 $cfg=require DB_CONFIG_FILE;
 try{$pdo=new PDO('mysql:host='.$cfg['host'].';port='.$cfg['port'].';dbname='.$cfg['name'].';charset=utf8mb4',$cfg['user'],$cfg['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);return $pdo;}catch(Throwable $e){$pdo=null;return null;}
}

const PERMISSION_CATALOG = [
 'dashboard'=>'Dashboard',
 'nc'=>'Gestione NC — accesso categoria',
 'nc_create'=>'Gestione NC — Nuova NC',
 'nc_register'=>'Gestione NC — Registro NC',
 'nc_mine'=>'Gestione NC — Le mie segnalazioni',
 'nc_stats'=>'Gestione NC — Grafici e statistiche',
 'nc_actions'=>'Gestione NC — Tempistiche e azioni',
 'nc_view_all'=>'Gestione NC — Visualizza tutte le NC',
 'nc_edit'=>'Gestione NC — Modifica NC',
 'nc_convert'=>'Gestione NC — Invia in segnalazione',
 'nc_cancel'=>'Gestione NC — Annulla NC',
 'nc_manual_reference'=>'Gestione NC — Riferimento manuale',
 'nc_backdate'=>'Gestione NC — Modifica data rilevazione',
 'segnalazioni'=>'Gestione segnalazioni — accesso categoria',
 'seg_create'=>'Segnalazioni — Apri segnalazione',
 'seg_register'=>'Segnalazioni — Registro segnalazioni',
 'seg_mine'=>'Segnalazioni — Le mie segnalazioni',
 'attivita'=>'Gestione attività — accesso categoria',
 'task_assign'=>'Attività — Assegna attività',
 'task_due'=>'Attività — Attività in scadenza',
 'task_mine'=>'Attività — Le mie attività',
 'assistenza'=>'Assistenza Tecnica — accesso categoria',
 'ticket_create'=>'Assistenza — Nuovo Ticket Post-Vendita',
 'ticket_register'=>'Assistenza — Registro Ticket',
 'approvazioni'=>'Approvazioni',
 'archivio'=>'Archivio NC e segnalazioni',
 'richieste'=>'Aspetti Tecnici — accesso categoria',
 'account_request'=>'Aspetti Tecnici — Richieste di account',
 'technical_issues'=>'Aspetti Tecnici — Problemi tecnici segnalati',
 'utenti'=>'Aspetti Tecnici — Gestione account',
 'technical_options'=>'Aspetti Tecnici — Opzioni',
];
const PERMISSION_GROUPS = [
 'Generale'=>['dashboard'],
 'Gestione NC'=>['nc','nc_create','nc_register','nc_mine','nc_stats','nc_actions','nc_view_all','nc_edit','nc_convert','nc_cancel','nc_manual_reference','nc_backdate'],
 'Gestione segnalazioni'=>['segnalazioni','seg_create','seg_register','seg_mine'],
 'Gestione attività'=>['attivita','task_assign','task_due','task_mine'],
 'Assistenza Tecnica'=>['assistenza','ticket_create','ticket_register'],
 'Altre categorie'=>['approvazioni','archivio'],
 'Aspetti Tecnici'=>['richieste','account_request','technical_issues','utenti','technical_options'],
];
function portal_navigation(): array {return [
 ['label'=>'Dashboard','permission'=>'dashboard','href'=>'dashboard.php','section'=>'Dashboard','icon'=>'grid','hub'=>false],
 ['label'=>'Gestione NC','permission'=>'nc','href'=>'dashboard.php?section='.rawurlencode('Gestione NC'),'section'=>'Gestione NC','icon'=>'alert','hub'=>true],
 ['label'=>'Gestione segnalazioni','permission'=>'segnalazioni','href'=>'dashboard.php?section='.rawurlencode('Gestione segnalazioni'),'section'=>'Gestione segnalazioni','icon'=>'message','hub'=>true],
 ['label'=>'Gestione attività','permission'=>'attivita','href'=>'dashboard.php?section='.rawurlencode('Gestione attività'),'section'=>'Gestione attività','icon'=>'tasks','hub'=>true],
 ['label'=>'Assistenza Tecnica','permission'=>'assistenza','href'=>'dashboard.php?section='.rawurlencode('Assistenza Tecnica'),'section'=>'Assistenza Tecnica','icon'=>'support','hub'=>true],
 ['label'=>'Analisi Dati','permission'=>'nc_stats','href'=>'dashboard.php?section='.rawurlencode('Analisi Dati'),'section'=>'Analisi Dati','icon'=>'chart','hub'=>true],
 ['label'=>'Approvazioni','permission'=>'approvazioni','href'=>'approvals.php','section'=>'Approvazioni','icon'=>'approve','hub'=>false],
 ['label'=>'Archivio NC e segnalazioni','permission'=>'archivio','href'=>'archive.php','section'=>'Archivio NC e segnalazioni','icon'=>'archive','hub'=>false],
 ['label'=>'Aspetti Tecnici','permission'=>'richieste','href'=>'dashboard.php?section='.rawurlencode('Aspetti Tecnici'),'section'=>'Aspetti Tecnici','icon'=>'wrench','hub'=>true],
 ];}
function portal_child_routes(): array {return [
 'Segnala NC'=>'nc_new.php','Grafici e statistiche'=>'nc_stats.php','Tempistiche e azioni'=>'nc_timing.php','Azioni NC assegnate'=>'entity_actions.php?kind=nc','Registro NC'=>'nc_register.php','Le mie segnalazioni'=>'nc_mine.php',
 'Apri segnalazione'=>'seg_new.php','Azioni Segnalazioni assegnate'=>'entity_actions.php?kind=seg','Segnalazioni'=>'segnalazioni.php','Le mie segnalazioni'=>'segnalazioni.php?mine=1','Attività in scadenza'=>'tasks_due.php','Assegna attività'=>'task_assign.php',
 'Attività assegnate'=>'assigned_tasks.php',
 'Le mie attività'=>'my_tasks.php',
 'Gestione account'=>'users.php',
 'Richieste di account'=>'account_requests.php',
 'Richieste credenziali'=>'credential_requests.php',
 'Mio profilo'=>'profile.php',
 'Configurazione mail'=>'mail_config.php',
 'Opzioni'=>'technical_options.php',
 ];}
function portal_route_for_label(string $label,string $fallback='#'): string {$routes=portal_child_routes();return $routes[$label]??$fallback;}

const ROLES = ['Admin','Responsabile','HR','HQSE','Alta Direzione','Operatore','Esterno'];
const DEPARTMENTS = ['Collaudo','Assemblaggio','Magazzino','Progettazione','Assistenza Tecnica','Pianificazione','HR','QHSE Compliance'];

const ROLE_PERMISSIONS = [
 'Admin' => ['dashboard','nc','nc_create','nc_register','nc_mine','nc_stats','nc_actions','nc_view_all','nc_edit','nc_convert','nc_cancel','nc_manual_reference','nc_backdate','segnalazioni','seg_create','seg_register','seg_mine','attivita','task_assign','task_due','task_mine','assistenza','ticket_create','ticket_register','approvazioni','archivio','richieste','account_request','technical_issues','utenti','technical_options'],
 'Responsabile' => ['dashboard','nc','nc_create','nc_register','nc_mine','nc_stats','nc_actions','nc_view_all','nc_edit','nc_convert','segnalazioni','seg_create','seg_register','seg_mine','attivita','task_assign','task_due','task_mine','assistenza','ticket_create','ticket_register','approvazioni','archivio','richieste','account_request','technical_issues'],
 'HR' => ['dashboard','segnalazioni','seg_create','seg_register','seg_mine','attivita','task_assign','task_due','task_mine','approvazioni','archivio','richieste','account_request','technical_issues'],
 'HQSE' => ['dashboard','nc','nc_create','nc_register','nc_mine','nc_stats','nc_actions','nc_view_all','nc_edit','nc_convert','nc_cancel','nc_manual_reference','nc_backdate','segnalazioni','seg_create','seg_register','seg_mine','attivita','task_assign','task_due','task_mine','assistenza','ticket_create','ticket_register','approvazioni','archivio','richieste','account_request','technical_issues'],
 'Alta Direzione' => ['dashboard','task_assign','nc','nc_register','nc_stats','nc_view_all','segnalazioni','seg_register','attivita','task_due','approvazioni','archivio'],
 'Operatore' => ['dashboard','nc','nc_create','nc_mine','segnalazioni','seg_create','seg_mine','attivita','task_mine','assistenza','ticket_create','richieste','account_request','technical_issues'],
 'Esterno' => ['dashboard','assistenza','ticket_create','richieste','account_request'],
];

function start_secure_session(): void {
 if (session_status() === PHP_SESSION_ACTIVE) return;
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']),'httponly'=>true,'samesite'=>'Lax']);
 session_start();
}
function csrf_token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(string $token): bool { return isset($_SESSION['csrf']) && hash_equals((string)$_SESSION['csrf'],$token); }
function is_authenticated(): bool { return !empty($_SESSION['user']); }
function current_user(): array { return (array)($_SESSION['user'] ?? []); }
function is_admin(): bool { return (current_user()['role'] ?? '') === 'Admin'; }
function ensure_permissions_store(): void {
 ensure_user_store();
 if(!file_exists(PERMISSIONS_FILE)){
  $roles=[]; foreach(ROLES as $role) $roles[$role]=ROLE_PERMISSIONS[$role] ?? [];
  file_put_contents(PERMISSIONS_FILE,json_encode(['roles'=>$roles,'users'=>[]],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
 }
}
function load_permissions(): array {
 if($db=db()){ $roles=[];foreach(ROLES as $r)$roles[$r]=[];foreach($db->query('SELECT role, permission_key FROM role_permissions')->fetchAll() as $x)$roles[$x['role']][]=$x['permission_key'];$users=[];foreach($db->query('SELECT user_id, permission_key FROM user_permissions')->fetchAll() as $x){$users[$x['user_id']]['mode']='custom';$users[$x['user_id']]['permissions'][]=$x['permission_key'];}return ['roles'=>$roles,'users'=>$users];}
 ensure_permissions_store();
 $data=json_decode((string)file_get_contents(PERMISSIONS_FILE),true);
 if(!is_array($data)) $data=[];
 $data['roles']=is_array($data['roles']??null)?$data['roles']:[];
 $data['users']=is_array($data['users']??null)?$data['users']:[];
 return $data;
}
function save_permissions(array $data): bool {
 if($db=db()){try{$db->beginTransaction();$db->exec('DELETE FROM role_permissions');$q=$db->prepare('INSERT INTO role_permissions(role,permission_key) VALUES(?,?)');foreach(($data['roles']??[]) as $r=>$ps)foreach($ps as $x)$q->execute([$r,$x]);$db->exec('DELETE FROM user_permissions');$q=$db->prepare('INSERT INTO user_permissions(user_id,permission_key) VALUES(?,?)');foreach(($data['users']??[]) as $id=>$o)if(($o['mode']??'')==='custom')foreach(($o['permissions']??[]) as $x)$q->execute([$id,$x]);$db->commit();return true;}catch(Throwable $e){if($db->inTransaction())$db->rollBack();return false;}}
 ensure_permissions_store(); $tmp=PERMISSIONS_FILE.'.tmp';$ok=file_put_contents($tmp,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;return $ok&&rename($tmp,PERMISSIONS_FILE);
}
function effective_permissions_for(array $user): array {
 $role=(string)($user['role']??'');
 // Regola inderogabile: ogni account Admin ha sempre accesso completo.
 // Le configurazioni salvate per ruolo o account non possono ridurne i permessi.
 if($role==='Admin') return array_keys(PERMISSION_CATALOG);
 $settings=load_permissions(); $id=(string)($user['id']??'');
 $rolePermissions=$settings['roles'][$role] ?? (ROLE_PERMISSIONS[$role] ?? []);
 $override=$settings['users'][$id] ?? null;
 if(is_array($override) && ($override['mode']??'inherit')==='custom') return array_values(array_intersect(array_keys(PERMISSION_CATALOG),(array)($override['permissions']??[])));
 return array_values(array_intersect(array_keys(PERMISSION_CATALOG),(array)$rolePermissions));
}
function can(string $permission): bool { return in_array($permission,effective_permissions_for(current_user()),true); }
function can_any(array $permissions): bool { foreach($permissions as $permission)if(can($permission))return true;return false; }
function require_permission(string $permission): void { require_login();if(!can($permission)){http_response_code(403);exit('Accesso negato. Permesso richiesto: '.e($permission));} }
function require_login(): void { if(!is_authenticated()){ header('Location: index.php'); exit; } }
function require_admin(): void { require_login(); if(!is_admin()){ http_response_code(403); exit('Accesso negato. Funzione riservata agli amministratori.'); } }
function e(string $value): string { return htmlspecialchars($value,ENT_QUOTES,'UTF-8'); }
function valid_password(string $password): bool { return strlen($password)>=6 && preg_match('/[A-Za-z]/',$password)===1 && preg_match('/\d/',$password)===1; }
function ensure_user_store(): void {
 if(!is_dir(DATA_DIR)) mkdir(DATA_DIR,0775,true);
 if(!file_exists(USERS_FILE)){
  $seed=[['id'=>bin2hex(random_bytes(8)),'email'=>'admin@mesar.local','name'=>'Wissem','surname'=>'Achour','role'=>'Admin','department'=>null,'password_hash'=>password_hash('Admin123!',PASSWORD_DEFAULT),'active'=>true,'created_at'=>date('c'),'updated_at'=>date('c')]];
  file_put_contents(USERS_FILE,json_encode($seed,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);
 }
}
function load_users(): array {if($db=db()){return array_map(fn($u)=>$u+['active'=>(bool)$u['active']],$db->query('SELECT * FROM users ORDER BY created_at')->fetchAll());}ensure_user_store();$data=json_decode((string)file_get_contents(USERS_FILE),true);return is_array($data)?$data:[];}
function save_users(array $users): bool {if($db=db()){try{$db->beginTransaction();$ids=array_column($users,'id');if($ids){$marks=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("DELETE FROM users WHERE id NOT IN ($marks)");$q->execute($ids);}else$db->exec('DELETE FROM users');$q=$db->prepare('INSERT INTO users(id,email,name,surname,role,department,password_hash,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE email=VALUES(email),name=VALUES(name),surname=VALUES(surname),role=VALUES(role),department=VALUES(department),password_hash=VALUES(password_hash),active=VALUES(active),updated_at=VALUES(updated_at)');foreach($users as $u)$q->execute([$u['id'],$u['email'],$u['name'],$u['surname'],$u['role'],$u['department']??null,$u['password_hash'],!empty($u['active'])?1:0,mysql_datetime((string)$u['created_at']),mysql_datetime((string)$u['updated_at'])]);$db->commit();return true;}catch(Throwable $e){if($db->inTransaction())$db->rollBack();return false;}}ensure_user_store();$tmp=USERS_FILE.'.tmp';$ok=file_put_contents($tmp,json_encode(array_values($users),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;return $ok&&rename($tmp,USERS_FILE);}

function load_segnalazioni(): array {if(!file_exists(SEG_FILE))return []; $x=json_decode((string)file_get_contents(SEG_FILE),true);return is_array($x)?$x:[];}
function save_segnalazioni(array $rows): bool {if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0775,true);return file_put_contents(SEG_FILE,json_encode(array_values($rows),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function generate_seg_reference(array $rows,string $date): string {$prefix='SEG-'.date('ymd',strtotime($date)).'-';$max=0;foreach($rows as $r)if(str_starts_with((string)($r['reference']??''),$prefix))$max=max($max,(int)substr((string)$r['reference'],-3));return $prefix.str_pad((string)($max+1),3,'0',STR_PAD_LEFT);}
function find_segnalazione(string $id): ?array {foreach(load_segnalazioni() as $r)if((string)($r['id']??'')===$id)return $r;return null;}
function entity_reference_map(): array {$map=[];foreach(load_ncs() as $r)$map[(string)$r['id']]=$r['reference'];foreach(load_segnalazioni() as $r)$map[(string)$r['id']]=$r['reference'];return $map;}
function entity_view_url(string $id): string {return find_segnalazione($id)?'seg_view.php?id='.rawurlencode($id):'nc_view.php?id='.rawurlencode($id);}
function reassign_actions_entity(string $from,string $to): bool {$rows=load_action_store();$changed=false;foreach($rows as &$a)if((string)($a['nc_id']??'')===$from){$a['nc_id']=$to;$changed=true;}unset($a);if($changed&&!save_action_store($rows))return false;if(workflow_uses_db())try{$q=db()->prepare('SELECT COUNT(*) FROM nonconformities WHERE id=?');$q->execute([$to]);$targetIsNc=(int)$q->fetchColumn()>0;if($targetIsNc){db()->prepare('UPDATE nc_actions SET nc_id=? WHERE nc_id=?')->execute([$to,$from]);}else{db()->prepare('DELETE FROM nc_actions WHERE nc_id=?')->execute([$from]);}}catch(Throwable $e){error_log('reassign actions mirror: '.$e->getMessage());}return true;}
function delete_actions_for_entity(string $id): void {$rows=array_values(array_filter(load_action_store(),fn($a)=>(string)($a['nc_id']??'')!==$id));save_action_store($rows);if(workflow_uses_db())try{db()->prepare('DELETE FROM nc_actions WHERE nc_id=?')->execute([$id]);}catch(Throwable $e){error_log('delete entity actions: '.$e->getMessage());}}
function refresh_seg_status(string $id): string {$rows=load_segnalazioni();foreach($rows as &$r)if((string)$r['id']===$id){$actions=array_values(array_filter(all_nc_actions(),fn($a)=>(string)($a['nc_id']??'')===$id));$allClosed=$actions&&count(array_filter($actions,fn($a)=>(string)($a['status']??'')==='CHIUSA'))===count($actions);$r['status']=$allClosed?'CHIUSA':'APERTA';$r['action_status']=$actions?($allClosed?'COMPLETATE':'IN CORSO'):'DA DEFINIRE';$status=$r['status'];}unset($r);save_segnalazioni($rows);return $status??'APERTA';}
function ensure_nc_store(): void {
 if(!is_dir(DATA_DIR)) mkdir(DATA_DIR,0775,true);
 if(!is_dir(NC_UPLOAD_DIR)) mkdir(NC_UPLOAD_DIR,0775,true);
 if(!file_exists(NC_FILE)) file_put_contents(NC_FILE,"[]",LOCK_EX);
}
function load_ncs(): array {
 ensure_nc_store();$json=json_decode((string)file_get_contents(NC_FILE),true);$json=is_array($json)?$json:[];$jsonMap=[];foreach($json as $r)$jsonMap[(string)($r['id']??'')]=$r;
 if($db=db())try{$rows=$db->query('SELECT * FROM nonconformities ORDER BY created_at')->fetchAll();$fromDb=$db->query('SELECT nc_id,original_name AS original,stored_name AS stored,file_size AS size FROM nc_attachments')->fetchAll();$attachmentMap=[];foreach($fromDb as $a)$attachmentMap[(string)$a['nc_id']][(string)$a['stored']]=['original'=>$a['original'],'stored'=>$a['stored'],'size'=>(int)$a['size']];foreach($jsonMap as $id=>$jr)foreach(($jr['attachments']??[]) as $a){$stored=(string)($a['stored']??$a['stored_name']??'');if($stored!=='')$attachmentMap[$id][$stored]=['original'=>(string)($a['original']??$a['original_name']??'Allegato'),'stored'=>$stored,'size'=>(int)($a['size']??0)];}foreach($rows as &$r){$id=(string)$r['id'];$r['attachments']=array_values($attachmentMap[$id]??[]);$r['quantity']=(float)$r['quantity'];foreach(['previous_status','archived_at','archived_by'] as $k)if(isset($jsonMap[$id][$k]))$r[$k]=$jsonMap[$id][$k];}unset($r);return $rows;}catch(Throwable $e){error_log('NC load DB: '.$e->getMessage());}
 return $json;
}
function save_ncs(array $rows): bool {
 ensure_nc_store();$jsonOk=file_put_contents(NC_FILE,json_encode(array_values($rows),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;
 $db=db();if($db)try{$db->beginTransaction();$q=$db->prepare('INSERT INTO nonconformities(id,reference,version,detection_date,monitoring_category,sgi_scope,pn,name,occasion,description,supplier,ddt,quantity,unit,lot_serial,notes,area,type,reported_by,status,action_status,deadline,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE reference=VALUES(reference),version=VALUES(version),detection_date=VALUES(detection_date),monitoring_category=VALUES(monitoring_category),sgi_scope=VALUES(sgi_scope),pn=VALUES(pn),name=VALUES(name),occasion=VALUES(occasion),description=VALUES(description),supplier=VALUES(supplier),ddt=VALUES(ddt),quantity=VALUES(quantity),unit=VALUES(unit),lot_serial=VALUES(lot_serial),notes=VALUES(notes),area=VALUES(area),type=VALUES(type),reported_by=VALUES(reported_by),status=VALUES(status),action_status=VALUES(action_status),deadline=VALUES(deadline)');$qa=$db->prepare('INSERT INTO nc_attachments(nc_id,original_name,stored_name,file_size) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE original_name=VALUES(original_name),file_size=VALUES(file_size)');foreach($rows as $r){$q->execute([$r['id'],$r['reference'],$r['version']??'V.0.01',$r['detection_date'],$r['monitoring_category'],$r['sgi_scope'],$r['pn'],$r['name'],$r['occasion'],$r['description'],$r['supplier'],$r['ddt'],$r['quantity'],$r['unit'],$r['lot_serial'],$r['notes'],$r['area'],$r['type'],$r['reported_by'],$r['status'],$r['action_status'],$r['deadline'],$r['created_by'],mysql_datetime((string)$r['created_at'])]);foreach(($r['attachments']??[]) as $a){$stored=(string)($a['stored']??$a['stored_name']??'');if($stored!=='')$qa->execute([$r['id'],(string)($a['original']??$a['original_name']??'Allegato'),$stored,(int)($a['size']??0)]);}}$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('NC mirror DB: '.$e->getMessage());}
 return $jsonOk;
}
function format_date_it(?string $value,bool $withTime=false): string {if(!$value)return '—';$ts=strtotime($value);if($ts===false)return '—';return date($withTime?'d/m/Y H:i':'d/m/Y',$ts);}
function mysql_datetime(?string $value=null): string { $time=$value?strtotime($value):time(); return date('Y-m-d H:i:s',$time?:time()); }
function database_user_id(array $sessionUser): string {
 if($db=db()){
  $q=$db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');$q->execute([(string)($sessionUser['email']??'')]);$id=$q->fetchColumn();if($id)return (string)$id;
 }
 return (string)($sessionUser['id']??'');
}
function generate_nc_reference(array $rows, string $detectionDate): string { $time=strtotime($detectionDate); if($time===false) throw new InvalidArgumentException('Data rilevazione non valida.'); $prefix=date('ymd',$time); $used=[]; foreach($rows as $r){ if(preg_match('/^'.preg_quote($prefix,'/').'(\d{2})$/',(string)($r['reference']??''),$m))$used[(int)$m[1]]=true; } for($i=1;$i<=99;$i++)if(!isset($used[$i]))return $prefix.str_pad((string)$i,2,'0',STR_PAD_LEFT); throw new RuntimeException('Progressivo giornaliero esaurito per la data selezionata.'); }

function role_requires_department(string $role): bool { return in_array($role,['Responsabile','Operatore'],true); }
function department_members(string $department,?string $role=null): array {
 return array_values(array_filter(load_users(),fn($u)=>!empty($u['active'])&&($u['department']??null)===$department&&($role===null||($u['role']??'')===$role)));
}
function assignable_operators(array $manager): array {
 if(($manager['role']??'')==='Admin')return array_values(array_filter(load_users(),fn($u)=>!empty($u['active'])&&($u['role']??'')==='Operatore'));
 if(($manager['role']??'')!=='Responsabile'||empty($manager['department']))return [];
 return department_members((string)$manager['department'],'Operatore');
}
function can_assign_user(array $manager,array $target): bool {
 if(($target['role']??'')!=='Operatore'||empty($target['active']))return false;
 if(($manager['role']??'')==='Admin')return true;
 return ($manager['role']??'')==='Responsabile'&&!empty($manager['department'])&&($manager['department']??null)===($target['department']??null);
}
function load_action_store(): array {if(!file_exists(NC_ACTIONS_FILE))return []; $x=json_decode((string)file_get_contents(NC_ACTIONS_FILE),true);return is_array($x)?$x:[];}
function save_action_store(array $rows): bool {if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0775,true);return file_put_contents(NC_ACTIONS_FILE,json_encode(array_values($rows),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function workflow_uses_db(): bool {$db=db();return $db&&ensure_workflow_schema();}
function action_fingerprint(array $a): string {return hash('sha256',implode('|',[(string)($a['nc_id']??''),(string)($a['action_type']??''),trim(mb_strtolower((string)($a['description']??''))),(string)($a['assigned_to']??''),strtolower((string)($a['assigned_email']??'')),(string)($a['due_date']??'')]));}
function all_nc_actions(): array {
 $rows=load_action_store();
 if(!$rows&&workflow_uses_db())try{$rows=db()->query('SELECT * FROM nc_actions ORDER BY id')->fetchAll();foreach($rows as &$r){$r['uid']='db-'.$r['id'];$u=find_user_by_id((string)($r['assigned_to']??''));$r['assigned_email']=$u['email']??'';}unset($r);save_action_store($rows);}catch(Throwable $e){error_log('actions import: '.$e->getMessage());}
 $unique=[];$seen=[];foreach($rows as $r){$key=action_fingerprint($r);if(isset($seen[$key]))continue;$seen[$key]=true;$unique[]=$r;}if(count($unique)!==count($rows))save_action_store($unique);return $unique;
}
function add_nc_action(array $a): bool {
 $rows=all_nc_actions();$fp=action_fingerprint($a);foreach($rows as $r)if(action_fingerprint($r)===$fp)return true;
 $ids=array_map('intval',array_column($rows,'id'));$a['id']=$ids?max($ids)+1:1;$a['uid']='json-'.bin2hex(random_bytes(8));$jsonOk=save_action_store(array_merge($rows,[$a]));
 if(workflow_uses_db())try{$q=db()->prepare('INSERT INTO nc_actions(nc_id,action_type,description,assigned_to,due_date,status,approval_status,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)');$q->execute([$a['nc_id'],$a['action_type'],$a['description'],$a['assigned_to'],$a['due_date'],$a['status'],$a['approval_status'],$a['created_by'],mysql_datetime($a['created_at'])]);}catch(Throwable $e){error_log('action mirror DB: '.$e->getMessage());}
 return $jsonOk;
}
function update_nc_action(int $id,array $changes): bool {
 $rows=all_nc_actions();$found=false;foreach($rows as &$r)if((int)($r['id']??0)===$id){$r=array_merge($r,$changes);$found=true;}unset($r);$jsonOk=$found&&save_action_store($rows);
 if(workflow_uses_db())try{$allowed=['action_type','description','assigned_to','due_date','status','executed_at','evidence','forwarded_by','approval_status'];$set=[];$vals=[];foreach($changes as $k=>$v)if(in_array($k,$allowed,true)){$set[]="$k=?";$vals[]=$v;}if($set){$vals[]=$id;db()->prepare('UPDATE nc_actions SET '.implode(',',$set).' WHERE id=?')->execute($vals);}}catch(Throwable $e){error_log('action mirror update: '.$e->getMessage());}
 return $jsonOk;
}
function delete_action_by_id(int $id,string $entityId=''): bool {$rows=load_action_store();$before=count($rows);$rows=array_values(array_filter($rows,fn($a)=>!((int)($a['id']??0)===$id&&($entityId===''||(string)($a['nc_id']??'')===$entityId))));$ok=count($rows)===$before||save_action_store($rows);if(workflow_uses_db())try{db()->prepare('DELETE FROM nc_actions WHERE id=?'.($entityId!==''?' AND nc_id=?':''))->execute($entityId!==''?[$id,$entityId]:[$id]);}catch(Throwable $e){error_log('delete action: '.$e->getMessage());}return $ok;}
function pending_approval_count(array $user): int {$uid=database_user_id($user);$count=0;foreach(all_nc_actions() as $a){if(($user['role']??'')==='Responsabile'){$waiting=($a['forwarded_by']??'')===$uid&&($a['approval_status']??'')==='IN APPROVAZIONE';}else{$waiting=can_manage_nc($user)&&in_array(($a['approval_status']??''),['IN APPROVAZIONE','IN APPROVAZIONE QHSE'],true);}if($waiting)$count++;}return $count;}
function user_reminded_actions(array $user): array {$uid=database_user_id($user);$email=strtolower((string)($user['email']??''));$rows=[];foreach(all_nc_actions() as $a){$mine=(string)($a['assigned_to']??'')===$uid||strtolower((string)($a['assigned_email']??''))===$email;$open=!in_array((string)($a['status']??''),['CHIUSA'],true);if($mine&&$open&&!empty($a['reminder_at']))$rows[]=$a;}usort($rows,fn($a,$b)=>strcmp((string)($b['reminder_at']??''),(string)($a['reminder_at']??'')));return $rows;}
function user_open_task_count(array $user): int {$uid=database_user_id($user);$email=strtolower((string)($user['email']??''));$count=0;foreach(all_nc_actions() as $a)if(((string)($a['assigned_to']??'')===$uid||strtolower((string)($a['assigned_email']??''))===$email)&&!in_array((string)($a['status']??''),['CHIUSA'],true))$count++;return $count;}
function load_detail_store(): array {if(!file_exists(NC_DETAILS_FILE))return []; $x=json_decode((string)file_get_contents(NC_DETAILS_FILE),true);return is_array($x)?$x:[];}
function save_detail_store(array $x): bool {if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0775,true);return file_put_contents(NC_DETAILS_FILE,json_encode($x,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function ensure_workflow_schema(): bool {
 $db=db();if(!$db)return false;
 try{
  $db->exec("CREATE TABLE IF NOT EXISTS nc_details(nc_id VARCHAR(32) PRIMARY KEY,section2_json LONGTEXT NULL,section3_json LONGTEXT NULL,section4_json LONGTEXT NULL,last_editor_id VARCHAR(32) NULL,updated_at DATETIME NOT NULL,CONSTRAINT fk_detail_nc2 FOREIGN KEY(nc_id) REFERENCES nonconformities(id) ON DELETE CASCADE) ENGINE=InnoDB");
  $db->exec("CREATE TABLE IF NOT EXISTS nc_actions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,nc_id VARCHAR(32) NOT NULL,action_type VARCHAR(30) NOT NULL,description TEXT NOT NULL,assigned_to VARCHAR(32) NOT NULL,due_date DATE NOT NULL,status VARCHAR(30) NOT NULL DEFAULT 'APERTA',executed_at DATE NULL,evidence TEXT NULL,forwarded_by VARCHAR(32) NULL,approval_status VARCHAR(40) NOT NULL DEFAULT 'DA ESEGUIRE',created_by VARCHAR(32) NOT NULL,created_at DATETIME NOT NULL,INDEX idx_action_assigned(assigned_to),INDEX idx_action_nc(nc_id),CONSTRAINT fk_action_nc2 FOREIGN KEY(nc_id) REFERENCES nonconformities(id) ON DELETE CASCADE) ENGINE=InnoDB");
  return true;
 }catch(Throwable $e){error_log('Workflow schema: '.$e->getMessage());return false;}
}
function can_archive_nc(array $u): bool {return ($u['role']??'')==='Admin'||($u['role']??'')==='HQSE'||($u['department']??'')==='QHSE Compliance';}
function can_manage_nc(array $u): bool { return ($u['role']??'')==='Admin'||($u['role']??'')==='HQSE'||($u['department']??'')==='QHSE Compliance'; }
function load_nc_detail(string $id): array {
 $out=['s2'=>[],'s3'=>[],'s4'=>[],'actions'=>[]];$store=load_detail_store();
 if(isset($store[$id]))foreach(['s2','s3','s4'] as $k)$out[$k]=(array)($store[$id][$k]??[]);
 elseif(workflow_uses_db())try{$q=db()->prepare('SELECT * FROM nc_details WHERE nc_id=?');$q->execute([$id]);$r=$q->fetch()?:[];foreach(['section2_json'=>'s2','section3_json'=>'s3','section4_json'=>'s4'] as $c=>$k)$out[$k]=json_decode((string)($r[$c]??'{}'),true)?:[];}catch(Throwable $e){error_log('details read: '.$e->getMessage());}
 $users=[];foreach(load_users() as $u){$users[(string)$u['id']]=$u;$users[strtolower((string)$u['email'])]=$u;}
 foreach(all_nc_actions() as $a)if((string)($a['nc_id']??'')===$id){$u=$users[(string)($a['assigned_to']??'')]??$users[strtolower((string)($a['assigned_email']??''))]??[];$a['assignee_name']=$u['name']??'';$a['assignee_surname']=$u['surname']??'';$out['actions'][]=$a;}
 return $out;
}
function save_nc_detail_data(string $id,array $s2,array $s3,array $s4,string $editor): bool {
 $x=load_detail_store();$x[$id]=['s2'=>$s2,'s3'=>$s3,'s4'=>$s4,'last_editor_id'=>$editor,'updated_at'=>date('c')];$jsonOk=save_detail_store($x);
 if(workflow_uses_db())try{$q=db()->prepare('INSERT INTO nc_details(nc_id,section2_json,section3_json,section4_json,last_editor_id,updated_at) VALUES(?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE section2_json=VALUES(section2_json),section3_json=VALUES(section3_json),section4_json=VALUES(section4_json),last_editor_id=VALUES(last_editor_id),updated_at=NOW()');$q->execute([$id,json_encode($s2),json_encode($s3),json_encode($s4),$editor]);}catch(Throwable $e){error_log('details mirror DB: '.$e->getMessage());}
 return $jsonOk;
}
function refresh_nc_workflow_status(string $ncId): string {
 $rows=load_ncs();$idx=null;foreach($rows as $i=>$r)if((string)($r['id']??'')===$ncId)$idx=$i;if($idx===null)return 'APERTA';
 $d=load_nc_detail($ncId);$base=nc_status($d['s2'],$d['s3'],$d['s4']);$actions=$d['actions'];$allClosed=$actions&&count(array_filter($actions,fn($a)=>(string)($a['status']??'')==='CHIUSA'))===count($actions);
 $status=$base==='CHIUSA'?'CHIUSA':($allClosed&&$base==='IN PROGRESS'?'DA CHIUDERE':$base);$rows[$idx]['status']=$status;$rows[$idx]['action_status']=$actions?($allClosed?'COMPLETATE':'IN CORSO'):'DA DEFINIRE';save_ncs($rows);return $status;
}
function nc_status(array $s2,array $s3,array $s4): string {$p=!empty($s2['origin'])&&!empty($s2['ac'])&&!empty($s2['risks'])&&!empty($s2['completion'])&&!empty($s2['evaluation'])&&!empty($s2['evaluation_owner'])&&!empty($s2['evaluation_date'])&&!empty($s3['notes'])&&!empty($s3['owner'])&&!empty($s3['date']);$c=$p&&!empty($s4['effectiveness_owner'])&&!empty($s4['effectiveness_date'])&&!empty($s4['final_evaluation'])&&!empty($s4['closure_owner'])&&!empty($s4['closure_date']);return $c?'CHIUSA':($p?'IN PROGRESS':'APERTA');}
function find_user_by_id(string $id): ?array {foreach(load_users() as $u)if((string)($u['id']??'')===$id)return $u;return null;}
function find_user_by_email(string $email): ?array { foreach(load_users() as $u) if(strtolower((string)$u['email'])===strtolower($email)) return $u; return null; }


function standalone_task_id(): string {return 'task_'.bin2hex(random_bytes(8));}
function is_standalone_task(string $id): bool {return str_starts_with($id,'task_');}
function refresh_action_parent(string $id): void {if(find_segnalazione($id))refresh_seg_status($id);elseif(!is_standalone_task($id))refresh_nc_workflow_status($id);}
function action_snapshot(array $a): array {return ['action_type'=>(string)($a['action_type']??''),'description'=>(string)($a['description']??''),'assigned_to'=>(string)($a['assigned_to']??''),'due_date'=>(string)($a['due_date']??'')];}
function action_changes(array $before,array $after): array {$labels=['action_type'=>'Tipo','description'=>'Descrizione','assigned_to'=>'Responsabile','due_date'=>'Scadenza'];$out=[];foreach($labels as $k=>$label)if((string)($before[$k]??'')!==(string)($after[$k]??'')){$old=(string)($before[$k]??'—');$new=(string)($after[$k]??'—');if($k==='assigned_to'){$ou=find_user_by_id($old);$nu=find_user_by_id($new);$old=$ou?trim($ou['name'].' '.$ou['surname']):$old;$new=$nu?trim($nu['name'].' '.$nu['surname']):$new;}if($k==='due_date'){$old=format_date_it($old);$new=format_date_it($new);}$out[]="$label: $old → $new";}return $out;}
function notify_nc_action_update(string $ncId,array $before,array $after): array {$cfg=load_mail_config();if(empty($cfg['enabled']))return ['sent'=>0,'errors'=>[]];$changes=action_changes($before,$after);if(!$changes)return ['sent'=>0,'errors'=>[]];$nc=null;foreach(load_ncs() as $r)if((string)$r['id']===$ncId)$nc=$r;if(!$nc)return ['sent'=>0,'errors'=>[]];$u=find_user_by_id((string)($after['assigned_to']??''));$email=(string)($u['email']??$after['assigned_email']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL))return ['sent'=>0,'errors'=>['Email destinatario aggiornamento non valida']];$base=rtrim((string)$cfg['base_url'],'/');$vars=['reference'=>(string)$nc['reference'],'name'=>(string)($nc['name']??''),'pn'=>(string)($nc['pn']??''),'action'=>(string)($after['description']??''),'due_date'=>format_date_it((string)($after['due_date']??'')),'changes'=>implode("
",$changes),'nc_url'=>$base.'/nc_view.php?id='.rawurlencode($ncId),'task_url'=>$base.'/my_tasks.php?focus_reminder='.($after['id']??'').'#task-'.($after['id']??'')];try{$pdf=!empty($cfg['attach_pdf'])?nc_pdf_binary($nc,array_values(array_filter(all_nc_actions(),fn($a)=>(string)($a['nc_id']??'')===$ncId))):'';$ok=send_multipart_email($email,mail_tpl((string)$cfg['update_subject_template'],$vars),mail_tpl((string)$cfg['update_body_template'],$vars),$pdf,'NC-'.$nc['reference'].'.pdf',$cfg);return ['sent'=>$ok?1:0,'errors'=>[]];}catch(Throwable $e){error_log('NC update mail: '.$e->getMessage());return ['sent'=>0,'errors'=>[$e->getMessage()]];}}
/* Configurazione email e invio automatico NC */
if(!defined('MAIL_CONFIG_FILE'))define('MAIL_CONFIG_FILE',DATA_DIR.'/mail_config.json');
function default_mail_config(): array {return ['enabled'=>false,'transport'=>'mail','host'=>'','port'=>587,'encryption'=>'tls','username'=>'','password'=>'','from_email'=>'','from_name'=>'Mesar Quality Hub','reply_to'=>'','base_url'=>'','subject_template'=>'NC {reference} - {name} {pn}','body_template'=>"È stata assegnata una nuova attività relativa alla NC {reference}.\n\nAzione: {action}\nScadenza: {due_date}\n\nApri l’attività: {task_url}",'attach_pdf'=>true,'update_subject_template'=>'Aggiornamento NC {reference} - {name} {pn}','update_body_template'=>"La NC {reference} o una delle attività assegnate è stata aggiornata.\n\nModifiche:\n{changes}\n\nApri la NC: {nc_url}\nApri l’attività: {task_url}",'task_subject_template'=>'Nuova attività assegnata - {title}','task_body_template'=>"Ti è stata assegnata una nuova attività.\n\nTitolo: {title}\nAttività: {action}\nScadenza: {due_date}\n\nApri l’attività: {task_url}",'seg_subject_template'=>'Segnalazione {reference} - nuova attività','seg_body_template'=>"Ti è stata assegnata una nuova attività sulla segnalazione {reference}.\n\nAttività: {action}\nScadenza: {due_date}\n\nApri l’attività: {task_url}"];}
function load_mail_config(): array {$cfg=default_mail_config();if(is_file(MAIL_CONFIG_FILE)){$x=json_decode((string)file_get_contents(MAIL_CONFIG_FILE),true);if(is_array($x))$cfg=array_merge($cfg,$x);}return $cfg;}
function save_mail_config(array $cfg): bool {if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0775,true);return file_put_contents(MAIL_CONFIG_FILE,json_encode(array_merge(default_mail_config(),$cfg),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function mail_tpl(string $text,array $vars): string {foreach($vars as $k=>$v)$text=str_replace('{'.$k.'}',(string)$v,$text);return $text;}
function pdf_escape_text(string $s): string {$s=iconv('UTF-8','Windows-1252//TRANSLIT',$s)?:$s;return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s);}
function nc_pdf_binary_legacy(array $nc,array $actions=[]): string {$lines=['SCHEDA NON CONFORMITA','Riferimento: '.($nc['reference']??''),'Data: '.format_date_it((string)($nc['detection_date']??'')),'PN: '.($nc['pn']??'—'),'Denominazione: '.($nc['name']??'—'),'Categoria: '.($nc['monitoring_category']??'—'),'Segnalato da: '.($nc['reported_by']??'—'),'Descrizione: '.($nc['description']??'—'),'','AZIONI'];foreach($actions as $a)$lines[]='- '.($a['action_type']??'').' | '.($a['description']??'').' | Scadenza '.format_date_it((string)($a['due_date']??''));$content="BT\n/F1 11 Tf\n50 800 Td\n";foreach($lines as $i=>$line){if($i)$content.="0 -18 Td\n";$content.='('.pdf_escape_text(mb_substr((string)$line,0,115)).") Tj\n";}$content.="ET";$objs=[];$objs[]='1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj';$objs[]='2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj';$objs[]='3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >> endobj';$objs[]='4 0 obj << /Length '.strlen($content).' >> stream' . "\n".$content."\nendstream endobj";$objs[]='5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj';$pdf="%PDF-1.4\n";$offsets=[0];foreach($objs as $o){$offsets[]=strlen($pdf);$pdf.=$o."\n";}$xref=strlen($pdf);$pdf.="xref\n0 6\n0000000000 65535 f \n";for($i=1;$i<=5;$i++)$pdf.=sprintf('%010d 00000 n ',$offsets[$i])."\n";$pdf.="trailer << /Size 6 /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";return $pdf;}
function smtp_read($fp): string {$out='';while(($line=fgets($fp,515))!==false){$out.=$line;if(isset($line[3])&&$line[3]===' ')break;}return $out;}
function smtp_cmd($fp,string $cmd,array $ok): string {fwrite($fp,$cmd."\r\n");$r=smtp_read($fp);$code=(int)substr($r,0,3);if(!in_array($code,$ok,true))throw new RuntimeException('SMTP '.$code.': '.trim($r));return $r;}
function send_multipart_email(string $to,string $subject,string $body,string $pdf,string $pdfName,array $cfg): bool {$boundary='=_mqh_'.bin2hex(random_bytes(12));$fromName=str_replace(["\r","\n"],'',(string)$cfg['from_name']);$from=str_replace(["\r","\n"],'',(string)$cfg['from_email']);$to=str_replace(["\r","\n"],'',$to);$subject=str_replace(["\r","\n"],' ',$subject);$headers=['From: '.$fromName.' <'.$from.'>','MIME-Version: 1.0','Content-Type: multipart/mixed; boundary="'.$boundary.'"'];if(!empty($cfg['reply_to']))$headers[]='Reply-To: '.$cfg['reply_to'];$msg='--'.$boundary."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$body."\r\n";if($pdf!=='')$msg.='--'.$boundary."\r\nContent-Type: application/pdf; name=\"$pdfName\"\r\nContent-Disposition: attachment; filename=\"$pdfName\"\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($pdf))."\r\n";$msg.='--'.$boundary."--\r\n";if(($cfg['transport']??'mail')==='mail')return mail($to,'=?UTF-8?B?'.base64_encode($subject).'?=',$msg,implode("\r\n",$headers));$host=(string)$cfg['host'];$port=(int)$cfg['port'];$prefix=($cfg['encryption']??'')==='ssl'?'ssl://':'';$fp=stream_socket_client($prefix.$host.':'.$port,$errno,$errstr,12);if(!$fp)throw new RuntimeException("Connessione SMTP fallita: $errstr");stream_set_timeout($fp,12);smtp_read($fp);smtp_cmd($fp,'EHLO '.($_SERVER['SERVER_NAME']??'localhost'),[250]);if(($cfg['encryption']??'')==='tls'){smtp_cmd($fp,'STARTTLS',[220]);if(!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('TLS SMTP non disponibile');smtp_cmd($fp,'EHLO '.($_SERVER['SERVER_NAME']??'localhost'),[250]);}if(!empty($cfg['username'])){smtp_cmd($fp,'AUTH LOGIN',[334]);smtp_cmd($fp,base64_encode((string)$cfg['username']),[334]);smtp_cmd($fp,base64_encode((string)$cfg['password']),[235]);}smtp_cmd($fp,'MAIL FROM:<'.$from.'>',[250]);smtp_cmd($fp,'RCPT TO:<'.$to.'>',[250,251]);smtp_cmd($fp,'DATA',[354]);$raw='Subject: =?UTF-8?B?'.base64_encode($subject)."?=\r\nTo: <{$to}>\r\n".implode("\r\n",$headers)."\r\n\r\n".$msg;$raw=preg_replace('/(?m)^\./','..',$raw);fwrite($fp,$raw."\r\n.\r\n");$r=smtp_read($fp);if((int)substr($r,0,3)!==250)throw new RuntimeException('SMTP DATA: '.trim($r));smtp_cmd($fp,'QUIT',[221]);fclose($fp);return true;}
function notify_action_assignment(array $action,string $kind,string $reference='',string $title=''): array {$cfg=load_mail_config();if(empty($cfg['enabled']))return ['sent'=>0,'errors'=>[]];$u=find_user_by_id((string)($action['assigned_to']??''));$email=(string)($u['email']??$action['assigned_email']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL))return ['sent'=>0,'errors'=>['Email destinatario non valida']];$base=rtrim((string)$cfg['base_url'],'/');$vars=['reference'=>$reference,'title'=>$title?:'Attività assegnata','action'=>(string)($action['description']??''),'due_date'=>format_date_it((string)($action['due_date']??'')),'task_url'=>$base.'/my_tasks.php?focus_reminder='.($action['id']??'').'#task-'.($action['id']??'')];$sp=$kind==='seg'?'seg':'task';try{$ok=send_multipart_email($email,mail_tpl((string)$cfg[$sp.'_subject_template'],$vars),mail_tpl((string)$cfg[$sp.'_body_template'],$vars),'','',$cfg);if($ok)update_nc_action((int)$action['id'],['assignment_mail_sent_at'=>date('c'),'assignment_mail_to'=>$email]);return ['sent'=>$ok?1:0,'errors'=>[]];}catch(Throwable $e){error_log('assignment mail: '.$e->getMessage());return ['sent'=>0,'errors'=>[$e->getMessage()]];}}
function notify_nc_assignees(string $ncId): array {$cfg=load_mail_config();if(empty($cfg['enabled']))return ['sent'=>0,'errors'=>[]];$nc=null;foreach(load_ncs() as $r)if((string)$r['id']===$ncId)$nc=$r;if(!$nc)return ['sent'=>0,'errors'=>['NC non trovata']];$actions=array_values(array_filter(all_nc_actions(),fn($a)=>(string)($a['nc_id']??'')===$ncId));$pdf=!empty($cfg['attach_pdf'])?nc_pdf_binary($nc,$actions):'';$sent=0;$errors=[];foreach($actions as $a){if(!empty($a['assignment_mail_sent_at']))continue;$u=find_user_by_id((string)($a['assigned_to']??''));$email=(string)($u['email']??$a['assigned_email']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL)){$errors[]='Email non valida per azione '.$a['id'];continue;}$base=rtrim((string)$cfg['base_url'],'/');$taskUrl=$base.'/my_tasks.php?focus_reminder='.$a['id'].'#task-'.$a['id'];$vars=['reference'=>(string)$nc['reference'],'name'=>(string)($nc['name']??''),'pn'=>(string)($nc['pn']??''),'action'=>(string)$a['description'],'due_date'=>format_date_it((string)$a['due_date']),'task_url'=>$taskUrl];try{if(send_multipart_email($email,mail_tpl((string)$cfg['subject_template'],$vars),mail_tpl((string)$cfg['body_template'],$vars),$pdf,'NC-'.$nc['reference'].'.pdf',$cfg)){update_nc_action((int)$a['id'],['assignment_mail_sent_at'=>date('c'),'assignment_mail_to'=>$email]);$sent++;}}catch(Throwable $e){$errors[]=$email.': '.$e->getMessage();error_log('NC mail: '.$e->getMessage());}}return ['sent'=>$sent,'errors'=>$errors];}

/* PDF completo NC, strutturato come la stampa della scheda */
function nc_pdf_binary(array $nc,array $actions=[]): string {
 $d=load_nc_detail((string)$nc['id']);$s2=$d['s2'];$s3=$d['s3'];$s4=$d['s4'];
 $users=[];foreach(load_users() as $u)$users[(string)$u['id']]=trim($u['name'].' '.$u['surname'].' · '.$u['role']);
 $val=fn($v)=>trim((string)$v)!==''?(string)$v:'—';$usr=fn($id)=>$users[(string)$id]??'—';
 $esc=fn($x)=>pdf_escape_text(mb_substr((string)$x,0,150));
 $txt=function($x,$y,$text,$size=9,$bold=false)use($esc){return "BT /".($bold?'F2':'F1')." $size Tf $x $y Td (".$esc($text).") Tj ET\n";};
 $box=function($x,$y,$w,$h){return "0.82 0.85 0.88 RG 0.55 w $x $y $w $h re S\n";};
 $field=function($x,$y,$w,$label,$value)use($txt,$box){return $box($x,$y,$w,46).$txt($x+10,$y+31,strtoupper($label),6,true).$txt($x+10,$y+14,$value,8,false);};
 $pageHeader=function($page)use($txt,$nc){return $txt(46,814,date('d/m/y, H:i'),7).$txt(260,814,'NC '.($nc['reference']??''),7,true).$txt(535,20,$page.'/3',7);};
 $pages=[];$c=$pageHeader(1);$c.=$box(40,710,515,90).$txt(58,770,'MESAR QUALITY HUB',7,true).$txt(58,742,'Non conformità '.($nc['reference']??''),19,true).$txt(445,754,'Stato',9,true).$txt(480,754,$val($nc['status']??''),8,true);$c.=$box(40,88,515,600).$txt(55,660,'1. Identificazione',14,true);
 $fields=[['Riferimento',$nc['reference']??''],['Data rilevazione',format_date_it((string)($nc['detection_date']??''))],['Segnalato da',$nc['reported_by']??''],['Categoria di monitoraggio',$nc['monitoring_category']??''],['Ambito SGI',$nc['sgi_scope']??''],['PN',$nc['pn']??''],['Denominazione',$nc['name']??''],['Occasione / fase',$nc['occasion']??''],['Fornitore',$nc['supplier']??''],['DDT',$nc['ddt']??''],['Lotto / seriale',$nc['lot_serial']??''],['Quantità',($nc['quantity']??'').' '.($nc['unit']??'')],['Ambito',$nc['scope']??$nc['sgi_scope']??''],['Tipologia',$nc['type']??'']];$y=600;foreach(array_chunk($fields,2) as $row){$c.=$field(55,$y,235,$row[0][0],$val($row[0][1])).$field(305,$y,235,$row[1][0],$val($row[1][1]));$y-=55;}$c.=$field(55,$y,485,'Descrizione',$val($nc['description']??''));$y-=55;$c.=$field(55,$y,485,'Note',$val($nc['notes']??''));$pages[]=$c;
 $c=$pageHeader(2).$box(40,500,515,300).$txt(55,770,'2. Analisi e valutazione',14,true);$f=[['Categoria',$s2['category']??''],['Classificazione',$s2['classification']??''],['Origine',$s2['origin']??''],['Apertura AC',$s2['ac']??''],['Nuovi rischi',$s2['risks']??''],['Completamento previsto',format_date_it((string)($s2['completion']??''))],['Valutazione',$s2['evaluation']??''],['Responsabile valutazione',$usr($s2['evaluation_owner']??'')]];$y=700;foreach(array_chunk($f,2) as $row){$c.=$field(55,$y,235,$row[0][0],$val($row[0][1])).$field(305,$y,235,$row[1][0],$val($row[1][1]));$y-=55;}$c.=$field(55,$y,485,'Analisi causa radice',$val($s2['root_cause']??''));
 $c.=$box(40,245,515,235).$txt(55,450,'3. Vigilanza',14,true).$txt(55,423,'Vigilanza sul mercato',9,true);$flags=['Incidente'=>'incident','Incidente grave'=>'serious_incident','Richiamo prodotto'=>'recall','Comunicazione Autorità'=>'authority','Comunicazione Organismo controllo'=>'control_body'];$x=55;$y=388;foreach($flags as $lab=>$key){$c.=$field($x,$y,150,$lab,$val($s3[$key]??'NO'));$x+=160;if($x>380){$x=55;$y-=54;}}$c.=$txt(55,305,'Organizzazione e ambiente',9,true);$flags2=['Incidente sul lavoro'=>'work_incident','Infortunio'=>'injury','Near miss'=>'near_miss','Danno ambientale'=>'environmental_damage'];$x=55;$y=267;foreach($flags2 as $lab=>$key){$c.=$field($x,$y,150,$lab,$val($s3[$key]??'NO'));$x+=160;if($x>380){$x=55;$y-=54;}}$pages[]=$c;
 $c=$pageHeader(3).$box(40,410,515,390).$txt(55,770,'4. Azioni',14,true);$drawActions=function($items,$title,$y)use($txt,$box,$usr,$val){$out=$txt(55,$y,$title,9,true);$y-=22;$out.="0.05 0.26 0.34 rg 55 $y 485 22 re f\n".$txt(62,$y+8,'Azione',7,true).$txt(250,$y+8,'Responsabile',7,true).$txt(370,$y+8,'Scadenza',7,true).$txt(445,$y+8,'Stato',7,true);$y-=24;if(!$items){$out.=$txt(62,$y+8,'Nessuna azione definita.',7);$y-=24;}foreach($items as $a){$out.=$box(55,$y,485,25).$txt(62,$y+9,mb_substr((string)$a['description'],0,48),7).$txt(250,$y+9,mb_substr($usr($a['assigned_to']??''),0,24),7).$txt(370,$y+9,format_date_it((string)$a['due_date']),7).$txt(445,$y+9,$val($a['status']??''),7);$y-=27;}return [$out,$y-18];};$imm=array_values(array_filter($actions,fn($a)=>($a['action_type']??'')==='IMMEDIATA'));$cor=array_values(array_filter($actions,fn($a)=>($a['action_type']??'')==='CORRETTIVA/PREVENTIVA'));[$o,$y]=$drawActions($imm,'Azioni immediate',735);$c.=$o;[$o,$y]=$drawActions($cor,'Azioni correttive/preventive',$y);$c.=$o;$c.=$box(40,120,515,260).$txt(55,350,'5. Efficacia e chiusura',14,true);$f=[['Responsabile efficacia',$usr($s4['effectiveness_owner']??'')],['Data efficacia',format_date_it((string)($s4['effectiveness_date']??''))],['Valutazione finale',$s4['final_evaluation']??''],['Responsabile chiusura',$usr($s4['closure_owner']??'')],['Data chiusura',format_date_it((string)($s4['closure_date']??''))]];$y=285;foreach(array_chunk($f,2) as $row){$c.=$field(55,$y,235,$row[0][0],$val($row[0][1]));if(isset($row[1]))$c.=$field(305,$y,235,$row[1][0],$val($row[1][1]));$y-=58;}$pages[]=$c;
 $objs=[];$kids=[];$n=3;foreach($pages as $i=>$content){$pageObj=$n++;$streamObj=$n++;$kids[]="$pageObj 0 R";$objs[$pageObj]="$pageObj 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 9 0 R /F2 10 0 R >> >> /Contents $streamObj 0 R >> endobj";$objs[$streamObj]="$streamObj 0 obj << /Length ".strlen($content)." >> stream\n$content\nendstream endobj";}$objs[1]='1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj';$objs[2]='2 0 obj << /Type /Pages /Kids ['.implode(' ',$kids).'] /Count 3 >> endobj';$objs[9]='9 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj';$objs[10]='10 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj';ksort($objs);$pdf="%PDF-1.4\n";$offset=[0];foreach($objs as $id=>$obj){$offset[$id]=strlen($pdf);$pdf.=$obj."\n";}$max=max(array_keys($objs));$xref=strlen($pdf);$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";for($i=1;$i<=$max;$i++)$pdf.=isset($offset[$i])?sprintf('%010d 00000 n ',$offset[$i])."\n":"0000000000 00000 f \n";$pdf.="trailer << /Size ".($max+1)." /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";return $pdf;
}

if(!defined('ACCOUNT_REQUESTS_FILE'))define('ACCOUNT_REQUESTS_FILE',DATA_DIR.'/account_requests.json');
function load_account_requests(): array {if(!is_file(ACCOUNT_REQUESTS_FILE))return []; $x=json_decode((string)file_get_contents(ACCOUNT_REQUESTS_FILE),true);return is_array($x)?$x:[];}
function save_account_requests(array $x): bool {return file_put_contents(ACCOUNT_REQUESTS_FILE,json_encode(array_values($x),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function portal_slug(string $s): string {$s=iconv('UTF-8','ASCII//TRANSLIT',$s)?:$s;$s=strtolower(preg_replace('/[^a-zA-Z0-9]+/','.',$s));return trim($s,'.');}
function random_portal_password(): string {return substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%'),0,14);}
function send_simple_template_mail(string $to,string $subject,string $body): array {$cfg=load_mail_config();if(empty($cfg['enabled']))return ['sent'=>0,'errors'=>['Invio mail disabilitato']];try{$ok=send_multipart_email($to,$subject,$body,'','',$cfg);return ['sent'=>$ok?1:0,'errors'=>$ok?[]:['Invio non riuscito']];}catch(Throwable $e){return ['sent'=>0,'errors'=>[$e->getMessage()]];}}

if(!defined('CREDENTIAL_REQUESTS_FILE'))define('CREDENTIAL_REQUESTS_FILE',DATA_DIR.'/credential_requests.json');
function load_credential_requests(): array {if(!is_file(CREDENTIAL_REQUESTS_FILE))return []; $x=json_decode((string)file_get_contents(CREDENTIAL_REQUESTS_FILE),true);return is_array($x)?$x:[];}
function save_credential_requests(array $x): bool {return file_put_contents(CREDENTIAL_REQUESTS_FILE,json_encode(array_values($x),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function find_portal_user_by_contact_email(string $email): ?array {$email=strtolower(trim($email));if($u=find_user_by_email($email))return $u;foreach(load_account_requests() as $r)if(($r['status']??'')==='APPROVED'&&strtolower((string)$r['email'])===$email){$username=(string)($r['username']??'');if($username!==''&&($u=find_user_by_email($username.'@portal.local')))return $u;}return null;}
