<?php
declare(strict_types=1);
require __DIR__.'/config.php'; start_secure_session(); ensure_user_store();
if(is_authenticated()){header('Location: dashboard.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $login=strtolower(trim((string)($_POST['email']??'')));$email=str_contains($login,'@')?$login:$login.'@portal.local'; $password=(string)($_POST['password']??'');
 $attempts=(int)($_SESSION['login_attempts']??0); $locked=(int)($_SESSION['locked_until']??0);
 if($locked>time()) $error='Troppi tentativi. Riprova tra qualche minuto.';
 elseif(!verify_csrf((string)($_POST['csrf']??''))) $error='Sessione non valida. Ricarica la pagina.';
 else { $u=find_user_by_email($email); if($u && ($u['active']??false) && password_verify($password,(string)$u['password_hash'])){session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'name'=>trim($u['name'].' '.$u['surname']),'email'=>$u['email'],'role'=>$u['role'],'department'=>$u['department']??null];$_SESSION['login_attempts']=0;header('Location: dashboard.php');exit;} $attempts++;$_SESSION['login_attempts']=$attempts;if($attempts>=5){$_SESSION['locked_until']=time()+180;$_SESSION['login_attempts']=0;}$error='Email o password non corretti.'; }
}
?>
<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Accesso | <?= htmlspecialchars(APP_NAME) ?></title><link rel="stylesheet" href="assets/styles.css"></head>
<body class="login-page">
<div class="ambient ambient-one"></div><div class="ambient ambient-two"></div>
<main class="login-shell">
<section class="login-visual">
<div class="brand brand-light"><span class="brand-mark">M</span><span><?= htmlspecialchars(APP_NAME) ?></span></div>
<div><span class="eyebrow">Portale operativo</span><h1>Qualità, attività e assistenza in un unico spazio.</h1><p>Un’interfaccia moderna progettata per rendere immediato il lavoro quotidiano.</p></div>
<div class="visual-card"><span class="status-dot"></span><div><strong>Sistema disponibile</strong><small>Accesso protetto e sessione sicura</small></div></div>
</section>
<section class="login-panel">
<div class="mobile-brand"><span class="brand-mark">M</span><strong><?= htmlspecialchars(APP_NAME) ?></strong></div>
<div class="login-copy"><span class="eyebrow dark">Bentornato</span><h2>Accedi al portale</h2><p>Inserisci le tue credenziali per continuare.</p></div>
<?php if ($error): ?><div class="alert" role="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="login-form" autocomplete="on">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
<label>Username o email<div class="input-wrap"><span class="field-icon">@</span><input type="text" name="email" placeholder="nome.cognome" required autocomplete="username"></div></label>
<label>Password<div class="input-wrap"><span class="field-icon">●</span><input id="password" type="password" name="password" placeholder="Inserisci la password" required autocomplete="current-password"><button type="button" class="password-toggle" data-password-toggle aria-label="Mostra password">Mostra</button></div></label>
<div class="form-options"><label class="check"><input type="checkbox"> <span>Ricordami</span></label><a href="credential_request_public.php">Password dimenticata?</a></div>
<button class="primary-button" type="submit">Accedi <span>→</span></button>
</form><a class="account-request-button" href="account_request_public.php">Richiedi un account a Qualità</a>
<p class="copyright">© <?= date('Y') ?> <?= htmlspecialchars(APP_NAME) ?></p>
</section></main><script src="assets/app.js"></script></body></html>
