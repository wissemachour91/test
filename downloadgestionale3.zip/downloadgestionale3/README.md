# Mesar Quality Hub Pro UI

## Avvio
Richiede PHP 8+. Eseguire nella cartella:

```bash
php -S localhost:8000
```

Aprire `http://localhost:8000`.

## Login demo
- Email: `admin@mesar.local`
- Password: `Admin123!`

## Novità Pro
- 5 layout selezionabili: Classic, Compact, Top Nav, Floating, Focus
- 5 palette: Indigo, Ocean, Emerald, Sunset, Graphite
- Modalità scura, animazioni e densità regolabili
- Voce “Aspetto” nel menu profilo e pulsante rapido nella barra superiore
- Preferenze persistenti via localStorage
- Migliore contrasto, tipografia, focus, responsive e accessibilità
- Login PHP con sessione, CSRF, hash password e limitazione tentativi

## Produzione
Collegare utenti e ruoli a database, forzare HTTPS, configurare CSP, recupero password e audit log.

## Menu gerarchico aggiunto
- Gestione NC: Segnala NC, Registro NC, Grafici e statistiche, Tempistiche e azioni
- Gestione segnalazioni: Apri segnalazione, Segnalazioni, Le mie segnalazioni
- Gestione attività: Assegna attività, Attività in scadenza, Le mie attività
- Badge rossi numerici su categorie e sottocategorie per elementi nuovi/non letti
- Gruppi espandibili, compatibili con tutti i 5 layout e con il menu mobile

## Correzioni menu
- Le categorie con sottovoci ora partono chiuse.
- Si apre un solo gruppo alla volta.
- I badge demo sono stati rimossi: compariranno solo quando un conteggio reale sarà maggiore di zero.
- Rimossa la barra di scorrimento orizzontale dalla sidebar.
- La scrollbar verticale è più sottile e compare solo quando necessaria.

## Fix layout Compact, Focus e Top Nav
- In Compact e Focus, il click su una categoria apre temporaneamente la sidebar completa e mostra le sottocategorie.
- Alla selezione di una sottocategoria la sidebar torna automaticamente compatta.
- In Top Nav tutte le 9 voci principali sono distribuite sulla larghezza disponibile senza scrollbar.
- Le etichette lunghe possono disporsi su due righe e i sottomenu restano a tendina.

## Assistenza Tecnica
Sottocategorie aggiunte:
- Nuovo Ticket Post-Vendita, con icona ticket e simbolo più
- Registro Ticket, con icona ticket ed elenco

## Richieste tecniche
Sottocategorie aggiunte:
- Richieste di account, con icona utente e simbolo più
- Problemi Tecnici Segnalati, con icona tecnica e indicatore di anomalia

## Aggiornamento menu
- Rimossa la macro categoria “Le mie attività”.
- La sottocategoria “Le mie attività” resta disponibile dentro “Gestione attività”.

## Correzione selezione sottocategorie
- Selezionando una sottocategoria, per esempio “Registro NC”, la categoria principale resta espansa.
- La sottocategoria selezionata rimane evidenziata.
- La categoria padre resta evidenziata per rendere chiara la posizione nel menu.
- Su smartphone si chiude soltanto il pannello laterale, mantenendo lo stato della categoria.

## Correzione stato selezione menu
- Quando una macro categoria viene chiusa, vengono rimossi sia l'evidenziazione della macro categoria sia quella della sottocategoria.
- Aprendo un'altra macro categoria, ogni selezione precedente viene pulita.
- Selezionando una sottocategoria, resta evidenziata esclusivamente la relativa macro categoria.

## Correzione definitiva sidebar compatta
- Il pulsante freccia ora riduce realmente la sidebar a 92 px mostrando soltanto le icone.
- Il pulsante non scompare: resta visibile sul bordo della sidebar e cambia verso per permettere la riapertura.
- La compattazione chiude tutti i sottomenu e rimuove gli stati grafici residui.
- Lo spazio di lavoro si riallinea automaticamente alla sidebar compatta.
- In modalità compatta, passando sulle icone appare il nome della voce come tooltip.
- La preferenza compatta resta memorizzata anche dopo il ricaricamento.
- Top Nav è stato riallineato alle 8 macro voci effettive.

## Correzione palette Aspetto
- Risolto il conflitto delle variabili CSS che manteneva sempre la palette Indigo.
- Indigo, Ocean, Emerald, Sunset e Graphite ora cambiano realmente sidebar, pulsanti, accenti, card e stati selezionati.
- Aggiunte varianti coerenti per la modalità scura.
- La palette selezionata viene salvata in localStorage e ripristinata al caricamento.
- Aggiunto controllo sui valori salvati per evitare che preferenze non valide blocchino il pannello Aspetto.

## Due loghi aziendali
Sono inclusi due loghi segnaposto sovrapposti verticalmente nella parte alta della sidebar. Per personalizzarli basta sostituire:
- `assets/logos/logo-primary.svg`
- `assets/logos/logo-secondary.svg`

Dimensione consigliata: 250 x 100 px, preferibilmente SVG o PNG trasparente. I loghi usano `object-fit: contain`, quindi non vengono deformati. Se un file manca appare il fallback L1/L2. Nei layout compatti restano visibili in formato ridotto; in Top Nav vengono nascosti per lasciare spazio al menu.

## Gestione loghi dal pannello Aspetto
I due loghi sono ora nella barra superiore, immediatamente a sinistra di “Workspace”, come nel riferimento fornito.

Dal menu Profilo > Aspetto è possibile:
- caricare liberamente Logo 1 e Logo 2;
- usare PNG, JPG, WebP o SVG fino a 1,5 MB ciascuno;
- ridimensionarli da 24 a 72 px;
- regolare la distanza tra i loghi da 0 a 24 px;
- disporli in verticale oppure in orizzontale;
- mostrare o nascondere ogni logo;
- ripristinare i loghi segnaposto.

Le immagini e le impostazioni vengono salvate nel localStorage del browser. Per un ambiente multiutente definitivo, i loghi dovranno essere salvati sul server o nel database.

## Correzione menu compatto e selezioni
- Cliccando l'icona di una macro categoria nel menu compatto, la sidebar si espande temporaneamente a 300 px e mostra le sottocategorie.
- Aprendo un'altra macro categoria, la precedente viene chiusa e deselezionata.
- Non possono più restare selezionate più macro categorie contemporaneamente.
- Cliccando di nuovo la stessa icona, il pannello temporaneo si richiude e la selezione viene rimossa.
- Dopo la scelta di una sottocategoria, la sidebar torna compatta e mantiene solo la pagina scelta come contenuto corrente.
- Le voci semplici puliscono sempre gli stati precedenti.

## Account, ruoli e permessi
Ruoli inclusi: Admin, Responsabile, HR, HQSE, Alta Direzione, Operatore, Esterno.

L'Admin può aprire “Richieste tecniche > Richieste di account” e:
- creare, modificare, attivare/disattivare ed eliminare account;
- compilare email, nome, cognome, ruolo e password;
- generare automaticamente una password sicura;
- usare password di almeno 6 caratteri con almeno una lettera e un numero;
- consultare la matrice iniziale dei permessi per categoria.

Gli account sono salvati in `data/users.json` con password protette tramite `password_hash()`. Il file e la cartella `data` devono essere scrivibili da PHP e non devono essere pubblicamente scaricabili in produzione. L'account iniziale resta `admin@mesar.local` / `Admin123!` ed è assegnato al ruolo Admin.

## Riorganizzazione Aspetti Tecnici
La macro categoria “Richieste tecniche” è stata rinominata “Aspetti Tecnici”. Contiene ora:
- Richieste di account
- Problemi tecnici Segnalati
- Gestione account

Il modulo amministrativo completo per creare, modificare, disattivare ed eliminare utenti, insieme alla matrice ruoli e permessi, è stato spostato nella nuova voce “Gestione account”. La voce è accessibile soltanto agli utenti con ruolo Admin; per gli altri ruoli resta protetta anche tramite controllo server-side in `users.php`.

## Permessi personalizzabili
L'Admin può ora configurare i permessi in due livelli:
1. **Per ruolo**: modifica le categorie disponibili per Admin, Responsabile, HR, HQSE, Alta Direzione, Operatore ed Esterno.
2. **Per singolo account**: ogni utente può ereditare i permessi del proprio ruolo oppure avere una configurazione personale.

I permessi sono salvati in `data/permissions.json`. La Dashboard è sempre disponibile. La gestione account resta sempre concessa all'Admin attualmente collegato, per evitare il blocco amministrativo accidentale. Le voci non autorizzate vengono rimosse dal menu tramite controllo PHP server-side.

## Protezione inderogabile del ruolo Admin
- Ogni account con ruolo Admin ha sempre accesso a tutte le categorie presenti nel catalogo permessi.
- I permessi del ruolo Admin non possono essere modificati dall'interfaccia né tramite invio manuale di richieste POST.
- I permessi individuali degli account Admin non possono essere modificati.
- `effective_permissions_for()` restituisce sempre l'intero catalogo dei permessi quando il ruolo è Admin, ignorando eventuali configurazioni precedenti nei file JSON.
- L'interfaccia mostra un avviso di protezione e disabilita checkbox, modalità di ereditarietà e pulsanti di salvataggio per Admin.

## Layout Executive e coerenza area amministrativa
- Aggiunto il sesto layout **Executive**, selezionabile da Profilo > Aspetto.
- Executive usa un'impostazione ampia, chiara e direzionale: nessuna sidebar fissa, header bianco, contenuti larghi, card bianche, bordi sottili e ombre leggere, coerente con il riferimento fornito.
- Lo stesso layout Executive viene applicato sia alla dashboard sia alla pagina Gestione account.
- La pagina amministrativa ora legge le stesse preferenze di tema, palette e modalità scura del portale principale.
- È stato aggiunto il pulsante **Aspetto** anche nell'header amministrativo, con selezione di tutti i 6 layout e delle 5 palette.

## Sidebar sempre visibile
- Il layout Executive non nasconde più la barra laterale principale.
- Dashboard e pagine del portale mantengono la sidebar completa anche in Executive.
- La sezione Gestione account dispone ora della stessa navigazione laterale, con Aspetti Tecnici e Gestione account evidenziati.
- Su schermi inferiori a 900 px la sidebar amministrativa diventa un pannello mobile apribile con il pulsante menu.

## Filtro e ricerca account
Nella directory account sono disponibili:
- filtro immediato per ruolo tramite menu a tendina;
- ricerca istantanea per nome, cognome ed email;
- utilizzo combinato di ruolo e testo;
- contatore aggiornato automaticamente;
- messaggio dedicato quando non esistono risultati;
- pulsante Azzera per ripristinare rapidamente la lista.

Il filtro è eseguito interamente nel browser e non ricarica la pagina.

## Posizione della pagina preservata
Nella sezione Gestione account la posizione verticale viene salvata prima di ogni aggiornamento della pagina e ripristinata dopo il caricamento. Funziona con:
- selezione del ruolo nei permessi;
- selezione dell'account nei permessi individuali;
- salvataggio di permessi e account;
- modifica, eliminazione e collegamenti interni a `users.php`;
- qualsiasi form presente nella pagina amministrativa.

I filtri della directory continuano ad aggiornarsi senza ricaricare la pagina e quindi non producono alcun salto.

## Hub a griglia per le macro categorie
Le sottocategorie sono state eliminate dalla sidebar. Le macro categorie con funzioni interne aprono ora una pagina-hub dedicata composta da card quadrate animate:
- Gestione NC
- Gestione segnalazioni
- Gestione attività
- Assistenza Tecnica
- Aspetti Tecnici

Ogni card contiene icona, titolo, descrizione e freccia. Al passaggio del mouse la card si solleva, cambia bordo e ombra, anima l'icona e mette in evidenza la freccia. Colori, sfondi e accenti derivano dalle variabili del tema, quindi il nuovo hub è coerente con tutti i layout e tutte le palette. La card Gestione account continua ad aprire il modulo amministrativo reale.

## Eliminazione titoli ripetuti
La barra superiore non ripete più il nome della macro categoria. Ora mostra sempre il contesto stabile “Portale operativo / Quality Hub”, mentre il nome effettivo della sezione appare una sola volta nell'area contenuti. La soluzione è applicata a Dashboard, Gestione NC, Gestione segnalazioni, Gestione attività, Assistenza Tecnica, Aspetti Tecnici e alle voci semplici.

## Modulo Gestione NC V.0.01
- La card “Segnala NC” apre `nc_new.php`, form completo V.0.01 con validazione server-side e campi obbligatori.
- Il riferimento manuale è disponibile solo agli Admin; altrimenti viene generato automaticamente.
- Allegati multipli consentiti: JPG, PNG, WEBP, PDF, DOC, DOCX, XLS, XLSX e TXT, massimo 10 MB per file.
- I dati sono salvati in `data/nonconformities.json`; gli allegati in `data/uploads/nc`.
- Dopo il salvataggio la NC appare immediatamente in `nc_register.php`, accessibile dalla card “Registro NC”.

## Installazione MySQL
Aprire `install.php` dal browser e compilare i dati MySQL/MariaDB e l'account Admin. L'installer crea database, tabelle utenti, permessi, NC e allegati, scrive `data/database.php` e blocca reinstallazioni tramite `data/installed.lock`. Dopo il completamento eliminare o rinominare `install.php`. Se il database non è configurato, il progetto mantiene il fallback JSON usato nelle versioni precedenti.

## Correzione salvataggio NC e riferimento AAMMGGXX
Il salvataggio è stato separato in due richieste per ridurre i blocchi WAF/OpenResty degli hosting condivisi: i dati testuali vengono inviati URL-encoded a `nc_save.php`, mentre ogni allegato viene inviato singolarmente a `nc_upload.php`. Il riferimento automatico usa la data di rilevazione nel formato `AAMMGGXX`: ad esempio, per il 21/10/2026 genera `26102101`, poi `26102102`. Il progressivo occupa il primo numero libero da 01 a 99. Solo il ruolo QHSE può impostare un riferimento manuale; Admin e gli altri ruoli ricevono sempre il riferimento automatico.

## Fix database NC e riferimento manuale
L'errore “Impossibile salvare la NC nel database” era compatibile con due problemi tipici dopo l'installazione: data ISO 8601 non accettata da MySQL `DATETIME` e ID utente in sessione precedente all'installazione, non valido per la chiave esterna. Ora le date vengono convertite in `Y-m-d H:i:s` e l'ID autore viene riletto dal database tramite email. Per database già installati aprire una sola volta `update_database.php` come Admin, quindi uscire e accedere nuovamente.

Il campo Riferimento NC è visibile a tutti. Admin e QHSE possono modificarlo; gli altri ruoli lo vedono in sola lettura. Il placeholder è “Vuoto = riferimento Automatico”. Se vuoto, il riferimento AAMMGGXX viene calcolato dalla Data rilevazione effettiva.

## Redirect dopo il salvataggio NC
`nc_save.php` ora gestisce sia richieste AJAX sia invii HTML tradizionali. Se JavaScript non parte o viene bloccato dal browser/server, il salvataggio non mostra più il JSON grezzo: dopo il successo viene eseguito un redirect HTTP 303 verso il Registro NC, con conferma e riferimento assegnato. In caso di validazione fallita, l'utente torna al modulo con i campi conservati.

## Data rilevazione e Le mie segnalazioni
La Data rilevazione parte automaticamente dalla data odierna e non accetta date future. Solo Admin e QHSE possono modificarla, scegliendo oggi o una data precedente; tutti gli altri ruoli la vedono bloccata sulla data del giorno. Il riferimento AAMMGGXX continua a essere calcolato dalla Data rilevazione effettiva.

Nell'hub Gestione NC è stata aggiunta la card “Le mie segnalazioni”, collegata a `nc_mine.php`. La pagina filtra server-side tramite `created_by` e mostra soltanto le NC aperte dall'account corrente con riferimento, stato, azioni, scadenza e allegati. Nel Registro NC è stata rimossa la dicitura V.0.01 sotto il riferimento.

## Permessi granulari V.0.02
La gestione permessi comprende ora ogni categoria, sottocategoria e azione NC. È possibile configurare per ruolo e per singolo account: accesso alla macro categoria, Nuova NC, Registro NC, Le mie segnalazioni, statistiche, tempistiche, visualizzazione completa, modifica, invio in segnalazione, annullamento, riferimento manuale e retrodatazione; inoltre tutte le sottocategorie di Segnalazioni, Attività, Assistenza Tecnica e Aspetti Tecnici. Le card non autorizzate vengono rimosse dall'hub e le pagine reali applicano controlli server-side. Admin resta protetto con accesso completo. Aprire una volta `update_database.php` come Admin per aggiungere al database i nuovi permessi mantenendo le autorizzazioni precedenti.

## Torna indietro e sidebar persistente
Il pulsante “Dashboard” è stato sostituito da “Torna indietro”. Usa la cronologia reale del browser (`history.back()`), con fallback alla Dashboard se non esiste una pagina precedente. La Dashboard usa ora query `?section=` e History API per conservare correttamente la macro categoria di provenienza.

È stato aggiunto `app_sidebar.php`, menu laterale condiviso e filtrato dai permessi, alle pagine Nuova NC, Registro NC, Le mie segnalazioni e manutenzione database. La macro categoria corrente resta evidenziata. Su schermi inferiori a 900 px il menu diventa un pannello mobile con pulsante hamburger.

## Reparti e squadre
Sono disponibili i reparti: Collaudo, Assemblaggio, Magazzino, Progettazione, Assistenza Tecnica, Pianificazione e HR. Nel profilo account il campo Reparto compare ed è obbligatorio quando il ruolo è Responsabile o Operatore; cambiando ruolo verso un ruolo diverso il reparto viene rimosso. La tabella account mostra il reparto.

La relazione organizzativa è derivata dal reparto: `assignable_operators($manager)` restituisce, per un Responsabile, soltanto gli Operatori attivi dello stesso reparto; `can_assign_user($manager,$target)` impedisce assegnazioni tra reparti diversi. Admin può assegnare attività a tutti gli operatori. La pagina `departments.php`, riservata agli Admin, riepiloga per reparto responsabili e operatori. Per database esistenti aprire una volta `update_database.php` per aggiungere la colonna `department`.

## Workflow NC e azioni
Le NC nuove sono APERTE in rosso. Admin e QHSE Compliance possono modificare la scheda in quattro sezioni. Completando i campi obbligatori delle Sezioni 2 e 3 lo stato diventa IN PROGRESS in arancione; completando anche la Sezione 4 diventa CHIUSA in verde. Le azioni assegnate compaiono in `my_tasks.php`; evidenze e data avviano il flusso di approvazione. Un Responsabile può inoltrare solo a operatori del proprio reparto. `approvals.php` gestisce approvazione Responsabile e successiva approvazione QHSE. Eseguire `update_database.php` una volta per creare `nc_details` e `nc_actions`.

## Restyling Sezione 2 e tema
La pagina `nc_edit.php` carica ora palette, modalità scura, densità, animazioni e layout dalle stesse preferenze `mqh-prefs` del portale. La Sezione 2 usa griglia a due colonne e due gruppi dinamici separati: Azioni immediate e Azioni correttive/preventive. Ogni azione comprende descrizione, responsabile, data prevista, stato e rimozione. È possibile aggiungere più righe. Le azioni correttive sono visibili e salvabili solo quando “Necessità apertura AC?” è impostata su SI.

## Fix salvataggio Sezioni 2/3 e Le mie attività
Il salvataggio delle sezioni usa ora transazioni, gestione `Throwable`, rollback, messaggi in sessione e redirect alla scheda: nessun errore applicativo apre più una pagina bianca. La validazione lato browser controlla esclusivamente la sezione relativa al pulsante premuto, evidenzia in rosso ogni campo mancante, mostra l'elenco dei nomi e porta il focus sul primo errore. La validazione server ripete gli stessi controlli. `ensure_workflow_schema()` crea in modo idempotente le tabelle mancanti; “Le mie attività” mostra un avviso leggibile anziché un HTTP 500 se il database non è pronto.

## Logo globale e tema predefinito
I due loghi sono ora impostazioni aziendali globali salvate sul server in `data/appearance.json`. Solo Admin vede e può usare i controlli Logo; ogni modifica viene distribuita a tutti gli utenti e appare anche nella sidebar condivisa. Il tema scelto da Admin viene salvato come predefinito globale. Al primo accesso o su un nuovo dispositivo ogni utente eredita quel tema; successivamente può scegliere liberamente una preferenza personale salvata nel proprio browser. Le preferenze personali non cambiano il tema degli altri utenti. `appearance_api.php` protegge tutte le modifiche globali con autenticazione, ruolo Admin e token CSRF.

## Fix definitivo Ocean, loghi globali e attività
Ocean è il tema aziendale predefinito. Un account eredita il tema Admin finché non modifica esplicitamente la propria preferenza. Al primo caricamento Admin, eventuali loghi reali precedentemente salvati nel browser vengono migrati una sola volta in `data/appearance.json`, quindi diventano visibili a tutti gli account. Le azioni NC usano MySQL quando disponibile e il fallback `data/nc_actions.json` quando la connessione non è disponibile; il dettaglio usa `data/nc_details.json`. Il conteggio attività aperte appare sulla macro categoria Gestione attività, sulla card Le mie attività e nella sidebar condivisa. Il login conserva anche il reparto nella sessione per gli inoltri ai collaboratori.

## Correzione persistenza Sezioni 2/3, stato e attività
`data/nc_details.json` e `data/nc_actions.json` sono ora l'archivio canonico sempre scritto, mentre MySQL è una replica best-effort. Questo elimina la precedente condizione “split-brain” in cui il salvataggio finiva nel database ma la lettura passava al JSON, o viceversa. Anche `nonconformities.json` viene sempre aggiornato con lo stato prima dell'eventuale replica MySQL. Le attività memorizzano sia ID sia email dell'assegnatario, quindi restano visibili anche dopo una reinstallazione che modifica gli ID interni. Dopo il salvataggio la conferma riporta lo stato calcolato e il numero di azioni assegnate.

## Fix definitivo pulsante Salva Sezioni 2 e 3
La causa era nel browser: il codice disabilitava il pulsante prima di `requestSubmit(button)`. Un submitter disabilitato non viene incluso nella richiesta HTTP, quindi PHP riceveva `mode` vuoto, saltava tutte le sezioni e mostrava comunque successo. Ora il tipo di salvataggio viene scritto nel campo hidden `saveMode` e il form viene inviato direttamente. Il server rifiuta richieste prive di modalità valida. In caso di errore, anche le righe Azione immediata/correttiva vengono ripopolate. Lo ZIP non contiene file JSON vuoti, quindi non sovrascrive dati già presenti sul server.

## Deduplicazione azioni, riepilogo Sezione 4 e stato Da chiudere
Le azioni sono ora lette da un solo archivio canonico JSON; MySQL viene importato soltanto se il JSON è vuoto. La lettura elimina automaticamente i duplicati usando l'impronta NC + tipo + descrizione + assegnatario + scadenza, e l'inserimento è idempotente. Lo stato dell'azione è automatico: APERTA all'assegnazione, ESEGUITA dopo l'invio delle evidenze, CHIUSA dopo l'approvazione finale. La Sezione 4 mostra due tabelle separate per azioni immediate e correttive/preventive. Quando tutte le azioni della NC sono CHIUSE e le Sezioni 2/3 sono complete, lo stato NC diventa DA CHIUDERE in verde; completando la Sezione 4 diventa CHIUSA.

## Stati colorati, calendario e inoltro Responsabile
“Le mie attività” classifica automaticamente le card: Da eseguire (blu), In scadenza entro 7 giorni (giallo), Scaduta (rosso), Da approvare (viola), Chiusa (verde). Il calendario mensile mostra le attività nel giorno di scadenza con lo stesso colore e collega direttamente alla card. Il profilo viene ricaricato dal database/archivio tramite email, quindi ruolo e reparto non dipendono da una sessione vecchia. Per i Responsabili il riquadro “Inoltra a un collaboratore” è sempre visibile: elenca esclusivamente Operatori attivi dello stesso reparto; se non ce ne sono, mostra il motivo invece di nascondere l'opzione.

## Visualizzazione NC, PDF, scadenze a 3 giorni e approvazioni
`nc_view.php` è accessibile esclusivamente agli account con permesso `nc_view_all`; presenta tutte le sezioni, azioni, vigilanza ed efficacia. Il pulsante “Stampa / Salva PDF” usa la finestra di stampa del browser con layout A4 dedicato, consentendo stampa fisica o salvataggio PDF. `tasks_due.php` mostra a ogni utente soltanto le proprie attività aperte con scadenza da oggi ai prossimi 3 giorni. `approvals.php` separa “Da approvare” da “Approvate e rifiutate” e mostra riferimento NC, tipo azione, descrizione, assegnatario, scadenza, data esecuzione, stato, evidenze e collegamento alla relativa NC.

## Correzione sidebar operativa
I loghi aziendali sono stati rimossi dal menu laterale delle pagine operative. Restano esclusivamente nella testata superiore, come nella Dashboard. `app_sidebar.php` usa ora le stesse classi strutturali della Dashboard (`sidebar`, `brand`, `main-nav`, `nav-link`, `sidebar-note`) con larghezza 280 px, spaziature, icone, voce attiva e modalità compatta coerenti.

## Fix apertura Approvazioni dalla Dashboard
Esistevano due listener JavaScript sullo stesso link. Il primo eseguiva sempre `preventDefault()`, quindi il secondo non riusciva a navigare verso `approvals.php`: la voce diventava attiva ma restava visibile l'hub precedente. Entrambi i listener ora rispettano `data-direct=1`. È stato aggiunto il conteggio reale delle approvazioni in attesa nel menu della Dashboard e nella sidebar condivisa. La pagina Approvazioni usa `no-store` per evitare cache obsolete.

## Fix Visualizza NC e obbligatorietà azioni
L'HTTP 500 di `nc_view.php` era causato da un errore di sintassi nel ramo “Nessuna azione definita” (`if(!$list):`). La sintassi è stata corretta. Nel salvataggio Sezioni 2/3 è ora obbligatoria almeno un'Azione immediata completa. Se “Necessità apertura AC?” è SI, diventa obbligatoria anche almeno un'Azione correttiva/preventiva completa. Se è NO, il blocco correttivo viene nascosto, disabilitato e ignorato sia dal browser sia dal server. La validazione evidenzia Descrizione, Responsabile e Data prevista senza lasciare la pagina.

## Vigilanza completa, stampa azioni e pulsante Visualizza
La scheda `nc_view.php` mostra ora tutti i campi di Vigilanza sul mercato e Organizzazione/ambiente, con valori SI/NO, responsabile, data ed evidenze. Le tabelle Azioni usano un layout fisso a sei colonne, testo a capo e nessuna larghezza minima: non generano più una barra orizzontale e sono interamente visibili nella stampa A4/PDF. Nel Registro NC il gruppo pulsanti usa flexbox, altezze e padding uniformi; Visualizza è allineato a Modifica, In segnalazione e Annulla.

## Parità campi Nuova NC, Modifica e Visualizza
Sezione 1 di Modifica e Visualizza comprende ora tutti i campi della pagina Nuova NC: versione, data, categoria di monitoraggio, ambito SGI, PN, denominazione, occasione/fase, descrizione, fornitore, DDT, quantità, unità, lotto/seriale, note, ambito, tipologia, segnalato da e allegati. Modifica consente anche di aggiungere allegati conservando quelli esistenti; estensioni e upload sono validati lato server.

## Fix 403 salvataggio e download allegati
Il salvataggio modifica NC usa ora `nc_update.php` e invia soltanto dati testuali, evitando il blocco 403 di OpenResty/WAF riscontrato su `nc_sections_save.php` con richieste multipart. Gli allegati sono caricati separatamente da `nc_attachment_upload.php`, con controllo CSRF, ruolo, estensione e limite 10 MB. `nc_attachment.php` consente visualizzazione inline o download, verifica autenticazione, permesso NC, appartenenza del file alla NC e impedisce path traversal.

## Fix definitivo 403 OpenResty sugli allegati
L'hosting bloccava le richieste `multipart/form-data` dirette a endpoint PHP, prima dell'esecuzione dell'applicazione. Il caricamento allegati ora usa FileReader nel browser e invia un payload JSON/base64 a `nc_asset_store.php`, con un file per richiesta. Il server verifica sessione, ruolo, CSRF, dimensione massima 8 MB, estensione, base64, appartenenza della NC e scrittura atomica. L'endpoint multipart precedente è stato rimosso. Visualizzazione e download continuano tramite `nc_attachment.php`.

## Fix allegati Nuova NC e sincronizzazione database
La pagina Nuova NC usava ancora `nc_upload.php` con multipart, bloccato da OpenResty, quindi la NC veniva creata senza allegati. Ora Nuova NC usa lo stesso caricamento JSON/base64 di Modifica NC. `save_ncs()` salva gli allegati sia in `nonconformities.json` sia nella tabella `nc_attachments`; `load_ncs()` unisce gli allegati DB e JSON per recuperare anche upload precedenti. Il Registro mostra `SÌ (n)` e collega direttamente alla sezione allegati della scheda NC.

## Motivo obbligatorio per annullamento NC
Solo Admin e QHSE visualizzano il pulsante Annulla. Il pulsante apre una finestra che richiede obbligatoriamente una nota da 5 a 1000 caratteri. Il controllo viene ripetuto lato server. La NC resta archiviata con motivo, data e utente che ha effettuato l'annullamento. L'Archivio mostra queste informazioni; Visualizza NC evidenzia il motivo. Il ripristino conserva il motivo precedente nei dati di audit.

## Contenuti esclusivi della Dashboard
Panoramica operativa, statistiche, spazio operativo e scorciatoie sono ora visibili esclusivamente nella Dashboard principale. Le pagine categoria aperte con `dashboard.php?section=...` mostrano soltanto intestazione e sottocategorie. La correzione combina stato server-side (`category-view`) e regola globale `[hidden]{display:none!important}`, evitando che regole CSS come `display:grid` rendano visibili elementi marcati come nascosti.

## Blocco azioni unico nelle Segnalazioni
La pagina Apri segnalazione usa un solo blocco ripetibile. Ogni riga contiene Tipo azione (Immediata oppure Correttiva/preventiva), Descrizione, Responsabile e Data prevista. “Aggiungi azione” crea tutte le righe necessarie; “Rimuovi” elimina la riga. Le righe completamente vuote sono ignorate, mentre quelle parziali vengono validate. È stato inoltre corretto l'HTTP 500 del Registro Segnalazioni sostituendo l'ordinamento delle scadenze con una funzione sicura.

## Conversione bidirezionale NC e Segnalazioni
Solo Admin e QHSE possono convertire. “In segnalazione” crea un nuovo riferimento SEG, trasferisce campi, allegati e azioni, rimuove la NC dal Registro NC e conserva `original_nc_reference`, visibile nella colonna Tracciabilità e nella scheda Segnalazione. “In NC” crea invece una nuova NC con riferimento NC automatico, trasferisce allegati e azioni e rimuove la Segnalazione; come richiesto, la nuova NC non conserva né mostra il riferimento SEG. Le azioni mantengono stato, assegnatario, evidenze e workflow approvativo.

## Archiviazione Segnalazioni
Il comando Elimina nel Registro Segnalazioni non elimina più definitivamente. Solo Admin e QHSE possono usarlo; apre una finestra con motivo obbligatorio e imposta la segnalazione su ANNULLATA, conservando allegati e azioni. L'Archivio NC e segnalazioni mostra ora due sezioni separate per NC e Segnalazioni, ciascuna con motivo, data, autore, Visualizza e Ripristina. La cancellazione definitiva non è più esposta nell'interfaccia.

## Fix trasferimento azioni NC → Segnalazione
La tabella MySQL `nc_actions` ha una chiave esterna verso `nonconformities`: il tentativo di cambiare `nc_id` con un ID Segnalazione veniva rifiutato dal database e mostrava “Impossibile trasferire le azioni”. Il JSON workflow è ora la sorgente operativa per le azioni delle Segnalazioni; durante NC→SEG le azioni vengono trasferite nel JSON e le vecchie righe MySQL della NC vengono rimosse senza bloccare la conversione. La procedura è idempotente e riutilizza un'eventuale Segnalazione parziale già creata dal tentativo precedente, evitando duplicati.

## Modifica azioni nelle Segnalazioni
La pagina Modifica Segnalazione mostra ora tutte le azioni immediate e correttive/preventive, incluse quelle trasferite da una NC. Admin e QHSE possono cambiare tipo, descrizione, responsabile e data prevista, aggiungere nuove azioni o rimuoverle. Stato operativo, evidenze, data di esecuzione e stato approvativo delle azioni esistenti vengono conservati. Le nuove azioni partono da APERTA / DA ESEGUIRE. La rimozione aggiorna sia il repository JSON sia l'eventuale mirror MySQL.

## Rifiuto approvazioni, nuova scadenza e monitoraggio azioni
Ogni rifiuto richiede motivo e nuova scadenza. L'azione torna a APERTA / DA ESEGUIRE, elimina esecuzione ed evidenza precedenti e ricompare in Le mie attività. La regola vale sia per rifiuto Responsabile sia QHSE e per azioni NC o Segnalazioni. Nei rispettivi hub sono state aggiunte “Azioni NC assegnate” e “Azioni Segnalazioni assegnate”: mostrano azioni aperte raggruppate per record e ordinate per scadenza, con responsabile, assegnante, stato, approvazione e solleciti. Chi ha assegnato l'attività, Admin o QHSE può posticipare la scadenza; entro 3 giorni o a scadenza superata può registrare un sollecito di chiusura.

## Avviso solleciti per l'assegnatario
Il sollecito genera un avviso flottante globale visibile all'assegnatario in tutte le pagine. L'avviso mostra numero attività, descrizione dell'ultima attività e scadenza, con link diretto a Le mie attività. Nella pagina attività compare anche un riepilogo Priorità richiesta; le schede sollecitate sono evidenziate e riportano mittente, data/ora e numero del sollecito.

## Apertura diretta attività sollecitata
L'avviso flottante resta disponibile su tutte le pagine che caricano la sidebar condivisa e può essere chiuso con X per la sessione corrente. Il pulsante “Apri attività” ora passa l'ID dell'ultimo sollecito, apre `my_tasks.php`, scorre direttamente alla scheda corretta e la evidenzia temporaneamente. Non punta più al solo riepilogo generale dei solleciti.

## Menu laterale uniforme
Il menu condiviso usa ora la stessa misura e densità su tutte le pagine: larghezza 272 px, logo 42 px, righe categoria 44 px, font 11 px, icone 18 px e spaziatura verticale ridotta. Lo stato attivo usa il riquadro azzurro della schermata di riferimento. Su schermi bassi entra automaticamente una modalità ancora più compatta; su mobile il contenuto resta senza margine laterale. Le regole hanno priorità sulle vecchie varianti locali che rendevano alcune categorie troppo grandi.

## Altezza categorie Dashboard
La sidebar interna di `dashboard.php` usa ora una classe dedicata e le stesse proporzioni compatte della pagina Approvazioni: ogni categoria, compresa quella attiva, è alta 44 px; su schermi bassi passa a 39 px. Sono stati neutralizzati padding, altezza e trasformazioni ereditate dalle viste categoria e dai layout personalizzati, che rendevano “Gestione NC” e le altre voci eccessivamente alte.

## Email automatiche NC
In Aspetti tecnici è disponibile “Configurazione mail”. Admin e QHSE possono abilitare PHP `mail()` oppure SMTP autenticato, configurare host, porta, STARTTLS/SSL, credenziali, mittente, Reply-To, URL portale, oggetto e corpo tramite variabili. Quando una NC ha nuove azioni assegnate, ogni responsabile riceve una mail per ciascuna nuova azione con oggetto predefinito `NC {reference} - {name} {pn}`, PDF NC allegato e link diretto alla propria attività. L'invio è tracciato nell'azione per evitare duplicati; un errore email non annulla il salvataggio della NC.

## Aggiornamenti NC via email e attività generali
Le modifiche a descrizione, responsabile, tipo o scadenza di un'azione NC già comunicata generano una nuova email al responsabile attuale con elenco “prima → dopo”, PDF NC, link alla NC e link all'attività. Oggetto e corpo sono personalizzabili in Configurazione mail. In Gestione attività sono disponibili Assegna attività e Attività assegnate: i Responsabili assegnano ai collaboratori del proprio reparto; Admin, QHSE, Alta Direzione e HR assegnano a tutti. Le attività generali usano lo stesso repository e workflow: esecuzione, evidenze, approvazione, rifiuto con nuova scadenza, posticipo, sollecito e annullamento.

## Registro NC, PDF email e modelli assegnazione
Nel Registro NC è stata rimossa la colonna operativa “Azioni”; resta l'ultima colonna comandi. La colonna Scadenza legge esclusivamente `Sezione 2 > Data completamento prevista`. Il PDF allegato alle email NC è ora una scheda completa di 3 pagine modellata sulla stampa fornita: Identificazione, Analisi e valutazione, Vigilanza, Azioni, Efficacia e chiusura. Configurazione mail include modelli separati per assegnazione attività generale e attività delle Segnalazioni, entrambi con link diretto all'attività.

## Restyling accesso e inoltro esterno
Corretti contrasto e leggibilità del pulsante Accedi, ora viola con testo bianco esplicito. La richiesta account usa card compatta, campi a larghezza piena, focus accessibile e pulsanti leggibili. In Le mie attività, Responsabile, Admin e QHSE possono inoltrare a un utente autorizzato oppure inserire una email esterna: l'invitato riceve dettagli, scadenza, link alla richiesta account e link diretto all'attività utilizzabile dopo l'attivazione.

## Rifinitura richieste account
Rimosso definitivamente il blocco Accesso demo. La gestione richieste usa campi etichettati, menu ruolo e reparto, note separate, pulsante Accetta verde e Rifiuta rosso. Ruolo e reparto sono richiesti solo quando si approva; per rifiutare servono esclusivamente le note. I reparti disponibili includono Assemblaggio, Progettazione, Magazzino, Collaudo, Produzione, Qualità, QHSE Compliance, Acquisti, Commerciale, Assistenza Tecnica, Amministrazione, Risorse Umane, Alta Direzione e Altro. Le richieste in attesa producono un indicatore rosso su Aspetti Tecnici e su Richieste di account nella Dashboard.

## Indicatori nelle sottocategorie
Gli indicatori rossi non restano più soltanto sulla categoria principale. La Dashboard usa una mappa centralizzata dei contatori e mostra lo stesso numero sulla scheda della sottocategoria che contiene l'attività da vedere. Attualmente sono collegati Le mie attività, Approvazioni e Richieste di account; la somma viene riportata automaticamente anche sulla rispettiva categoria principale. Il rendering è generico: ogni nuova sottocategoria con contatore maggiore di zero riceve automaticamente il badge rosso.

## Recupero credenziali e Mio profilo
La pagina login accetta username oppure email e collega Password dimenticata a un modulo pubblico con email obbligatoria. Le richieste entrano in Aspetti tecnici > Richieste credenziali, con contatore rosso nella categoria e nella sottocategoria. Solo Admin può approvare: il sistema identifica l'account collegato, genera una password temporanea sicura, aggiorna l'hash e invia username, password e link di accesso via email. Il rifiuto usa il pulsante rosso e può includere note. Mio profilo mostra username, nome, cognome, ruolo e reparto in sola lettura; l'utente può cambiare esclusivamente la password inserendo quella corrente e due volte la nuova, con minimo 10 caratteri.

## Dimensione massima loghi
Il controllo Aspetto > Dimensione loghi consente ora valori da 24 px fino a 120 px, con incremento di 2 px. Il limite è applicato a tutte le istanze del pannello di personalizzazione e alla logica JavaScript di salvataggio/visualizzazione.

## Filtri automatici nei registri
Tutte le pagine che contengono tabelle o registri caricano `assets/table-filters.js`. Il componente legge automaticamente le intestazioni e i valori presenti, crea menu a tendina per le colonne utili, esclude comandi/azioni/allegati e aggiorna immediatamente le righe senza pulsante e senza ricaricare la pagina. I filtri possono essere combinati, mostrano il numero di record visibili e includono “Azzera filtri”. Il layout è adattivo per desktop, tablet e smartphone.

## Filtri Registro NC aggiornati
Nel Registro NC sono stati rimossi i filtri Riferimento, Scadenza e Descrizione. Sono stati aggiunti e mantenuti sempre visibili i filtri Categoria e Origine, anche quando al momento esiste un solo valore disponibile. Restano disponibili PN, Denominazione, Stato e Segnalato da quando contengono valori filtrabili. L'aggiornamento delle righe resta immediato, senza pulsante.

## Centro analisi NC
Grafici e statistiche è ora un centro analisi interattivo con grafici a barre, torta, linea, barre orizzontali e ciambella; cinque palette colore; periodo Dal/Al; filtri per Origine, PN, Segnalato da e Mese; raggruppamenti per mese, origine, categoria, PN, segnalatore e stato. Titolo ed etichette del report sono personalizzabili. KPI, grafico, legenda e tabella di sintesi si aggiornano immediatamente. “Stampa report PDF” usa il dialogo di stampa del browser con layout A4 ottimizzato, da cui selezionare Salva come PDF.

## Viste analitiche predefinite e leggibilità grafici
Aggiunte otto viste rapide: Segnalato da reparto, Analisi per PN, Prodotto/Organizzazione, Segnalazioni verso fornitori, Canale della segnalazione, Origine NC, Andamento mensile e Stato pratiche. Ogni scheda imposta automaticamente raggruppamento, tipo di grafico, palette e titolo del report. Le palette ora usano colori ad alto contrasto e realmente distinti. Etichette, valori, legenda, tabella e intestazioni del report sono state ingrandite.

## Tempistiche e azioni per reparto
La sezione calcola le performance delle attività assegnate confrontando scadenza, data di esecuzione e stato corrente. Le attività aperte oltre scadenza continuano ad accumulare giorni di ritardo. La classifica è ordinata dal reparto più critico al più puntuale usando: percentuale di azioni in ritardo + ritardo medio moltiplicato per 2 + cinque punti per ogni azione ancora aperta e scaduta. Sono visibili totale azioni, ritardi, aperte scadute, ritardo medio, massimo ritardo, puntualità delle chiuse, grafico comparativo e dettaglio delle azioni in ritardo.

## Categoria Analisi Dati
Le voci “Grafici e statistiche” e “Tempistiche e azioni” sono state rimosse da Gestione NC e spostate nella nuova categoria autonoma “Analisi Dati”. La categoria è posizionata nel menu principale tra Assistenza Tecnica e Approvazioni. I permessi esistenti `nc_stats` e `nc_actions` continuano a determinare la visibilità delle due sottocategorie e i collegamenti restano rispettivamente `nc_stats.php` e `nc_timing.php`.

## Menu Analisi Dati, ricerca, loghi e QR
Le pagine Centro analisi NC e Tempistiche e azioni impostano ora `Analisi Dati` come area attiva nel menu laterale. La ricerca della Dashboard indicizza categorie e sottocategorie visibili, filtra durante la digitazione, apre il primo risultato con Invio e supporta Ctrl/Cmd+K. I loghi della testata mantengono le proporzioni con `object-fit: contain`, senza ritagli, fino a 120 px. Tutte le pagine applicative mostrano in basso a destra un QR code piccolo generato sull'URL corrente, inclusi query string e identificativi della scheda, per l'accesso diretto alla stessa pagina. La generazione QR usa il servizio `api.qrserver.com`; richiede accesso internet dal browser.

## Opzioni QR code
In Aspetti Tecnici è disponibile la nuova voce “Opzioni”. Gli utenti autorizzati possono attivare o disattivare globalmente il QR code, impostare dimensione da 48 a 140 px, posizione sinistra/centro/destra, etichetta, testo inferiore e visibilità del titolo pagina. Le impostazioni sono salvate in `data/appearance.json` e applicate a tutte le pagine attraverso `window.MQH_GLOBAL_APPEARANCE`.

## Pulsanti indietro e lente di ricerca
Il componente globale `assets/page-tools.js` aggiunge automaticamente “Torna indietro” alle pagine applicative con intestazione che non possiedono già un comando equivalente. Il pulsante usa la cronologia solo quando il referrer appartiene allo stesso portale; in assenza di una pagina precedente valida torna alla Dashboard. La Dashboard utilizza ora una vera icona SVG a lente nel campo di ricerca, con evidenziazione al focus e senza caratteri simbolici dipendenti dal font.
