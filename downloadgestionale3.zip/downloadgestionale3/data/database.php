<?php
return array (
  'host' => 'sql207.infinityfree.com',
  'port' => 3306,
  'name' => 'if0_43111844_nuovo',
  'user' => 'if0_43111844',
  'pass' => 'KzcVEVwY79P',
);
