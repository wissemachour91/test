<?php
declare(strict_types=1);
require __DIR__.'/config.php';start_secure_session();require_admin();
$errors=[];$done=false;
try{
 $pdo=db();if(!$pdo)throw new RuntimeException('Connessione database non disponibile.');
 try{$pdo->exec("ALTER TABLE users ADD COLUMN department VARCHAR(80) NULL AFTER role");}catch(Throwable $ignore){}
 $pdo->exec("ALTER TABLE users MODIFY created_at DATETIME NOT NULL, MODIFY updated_at DATETIME NOT NULL");
 $pdo->exec("ALTER TABLE nonconformities MODIFY created_at DATETIME NOT NULL");
 $pdo->exec("ALTER TABLE nonconformities DROP FOREIGN KEY fk_nc_user");
 $pdo->exec("ALTER TABLE nonconformities ADD CONSTRAINT fk_nc_user FOREIGN KEY(created_by) REFERENCES users(id)");
 $pdo->exec("CREATE TABLE IF NOT EXISTS nc_details(nc_id VARCHAR(32) PRIMARY KEY,section2_json LONGTEXT,section3_json LONGTEXT,section4_json LONGTEXT,last_editor_id VARCHAR(32),updated_at DATETIME NOT NULL,FOREIGN KEY(nc_id) REFERENCES nonconformities(id) ON DELETE CASCADE) ENGINE=InnoDB");$pdo->exec("CREATE TABLE IF NOT EXISTS nc_actions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,nc_id VARCHAR(32) NOT NULL,action_type VARCHAR(30) NOT NULL,description TEXT NOT NULL,assigned_to VARCHAR(32) NOT NULL,due_date DATE NOT NULL,status VARCHAR(30) NOT NULL DEFAULT 'APERTA',executed_at DATE NULL,evidence TEXT NULL,forwarded_by VARCHAR(32) NULL,approval_status VARCHAR(40) NOT NULL DEFAULT 'DA ESEGUIRE',created_by VARCHAR(32) NOT NULL,created_at DATETIME NOT NULL,INDEX(assigned_to),FOREIGN KEY(nc_id) REFERENCES nonconformities(id) ON DELETE CASCADE) ENGINE=InnoDB");$permissionChildren=['nc'=>['nc_create','nc_register','nc_mine','nc_stats','nc_actions','nc_view_all','nc_edit','nc_convert','nc_cancel'],'segnalazioni'=>['seg_create','seg_register','seg_mine'],'attivita'=>['task_assign','task_due','task_mine'],'assistenza'=>['ticket_create','ticket_register'],'richieste'=>['account_request','technical_issues']];
 foreach($permissionChildren as $parent=>$children){$q=$pdo->prepare('SELECT DISTINCT role FROM role_permissions WHERE permission_key=?');$q->execute([$parent]);$roles=$q->fetchAll(PDO::FETCH_COLUMN);$ins=$pdo->prepare('INSERT IGNORE INTO role_permissions(role,permission_key) VALUES(?,?)');foreach($roles as $role)foreach($children as $child)$ins->execute([$role,$child]);}
 $admin=$pdo->prepare("SELECT DISTINCT role FROM role_permissions WHERE role='Admin'");$admin->execute();foreach(array_keys(PERMISSION_CATALOG) as $key){$pdo->prepare("INSERT IGNORE INTO role_permissions(role,permission_key) VALUES('Admin',?)")->execute([$key]);}
 $qhse=$pdo->prepare("INSERT IGNORE INTO role_permissions(role,permission_key) VALUES('QHSE',?)");foreach(['nc_manual_reference','nc_backdate'] as $key)$qhse->execute([$key]);
 $done=true;
}catch(Throwable $e){
 // Duplicate/missing FK conditions are harmless if columns already exist; retry only column normalization.
 try{$pdo=db();if(!$pdo)throw new RuntimeException('Connessione database non disponibile.');try{$pdo->exec("ALTER TABLE users ADD COLUMN department VARCHAR(80) NULL AFTER role");}catch(Throwable $ignore){}
 $pdo->exec("ALTER TABLE users MODIFY created_at DATETIME NOT NULL, MODIFY updated_at DATETIME NOT NULL");$pdo->exec("ALTER TABLE nonconformities MODIFY created_at DATETIME NOT NULL");$done=true;}catch(Throwable $inner){$errors[]=$inner->getMessage();}
}
?><!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aggiornamento database</title><?=appearance_bootstrap()?><link rel="stylesheet" href="assets/styles.css"></head><body class="app-page has-shared-sidebar"><?php $activeArea='Aspetti Tecnici'; include __DIR__.'/app_sidebar.php'; ?><main class="panel installer" style="max-width:760px;margin:40px auto;padding:30px"><span class="eyebrow dark">Manutenzione</span><h1>Aggiornamento database NC</h1><?php if($done):?><div class="notice success">Database aggiornato. Ora esci dal portale, accedi nuovamente e salva la NC.</div><a class="primary-button" href="logout.php">Esci e accedi di nuovo</a><?php else:?><div class="notice error"><b>Aggiornamento non riuscito</b><ul><?php foreach($errors as $x):?><li><?=e($x)?></li><?php endforeach;?></ul></div><?php endif;?></main><script src="assets/page-tools.js"></script></body></html>
